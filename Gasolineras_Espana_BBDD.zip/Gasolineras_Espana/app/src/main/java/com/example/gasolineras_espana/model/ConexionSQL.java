package com.example.gasolineras_espana.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSQL extends SQLiteOpenHelper {

    //Nombre de la base de datos
    private static final String DATABASE_NAME = "fuel4less.db";

    //Version de la base de datos
    private static final int VERSION = 2;

    private static final String CREATE_GASOLINERA= "CREATE TABLE gasolineras(" +
            "id_gasolinera TEXT PRIMARY KEY , " +
            "rotulo TEXT NOT NULL, " +
            "direccion TEXT NOT NULL, " +
            "municipio TEXT NOT NULL, " +
            "provincia TEXT NOT NULL, " +
            "codigo_postal TEXT NOT NULL, " +
            "horario TEXT NOT NULL, " +
            "latitud REAL NOT NULL, " +
            "longitud REAL NOT NULL, " +
            "precio_gasolina95 REAL NOT NULL, " +
            "precio_gasolina98 REAL NOT NULL, " +
            "precio_diesel REAL NOT NULL, " +
            "precio_diesel_premium REAL NOT NULL, " +
            "precio_glp REAL NOT NULL, " +
            "precio_gnc REAL NOT NULL, " +
            "precio_gnl REAL NOT NULL);";


    public ConexionSQL(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_GASOLINERA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS gasolineras");
        onCreate(db);
    }
}
