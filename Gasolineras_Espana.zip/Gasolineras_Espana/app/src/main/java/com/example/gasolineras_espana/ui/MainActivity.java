package com.example.gasolineras_espana.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class MainActivity extends AppCompatActivity {

    // Añadimos mAuth para activar la sesión real
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Inicializamos Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Tus campos tal y como los tenías
        EditText etUsuario = findViewById(R.id.etUsuario);
        EditText etContrasenia = findViewById(R.id.etContraseniaAntigua);
        Button btnLogin = findViewById(R.id.btnRegistro);
        TextView tvRegistrate = findViewById(R.id.tvRegistrate);

        btnLogin.setOnClickListener(v -> {
            String usuarioInput = etUsuario.getText().toString().trim();
            String passInput = etContrasenia.getText().toString().trim();

            if (usuarioInput.isEmpty() || passInput.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_campos_vacios), Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore db = FirebaseFirestore.getInstance();

            // 1. Buscamos el documento que coincida con el nombre de "usuario"
            db.collection("usuarios")
                    .whereEqualTo("usuario", usuarioInput)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {

                            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                                String dbPass = doc.getString("contrasenia");

                                // 2. Verificamos la contraseña en Firestore como tú querías
                                if (dbPass != null && dbPass.equals(passInput)) {

                                    // 3. ¡EL TRUCO!: Sacamos el correo oculto de ese documento
                                    String correoOculto = doc.getString("correo");

                                    if (correoOculto != null) {
                                        // 4. Iniciamos sesión en Firebase Auth en segundo plano usando ese correo
                                        mAuth.signInWithEmailAndPassword(correoOculto, passInput)
                                                .addOnCompleteListener(taskAuth -> {
                                                    if (taskAuth.isSuccessful()) {
                                                        // Éxito: Firebase Auth ya está activo y guardado en el móvil
                                                        Log.d("FirestoreLogin", "Login y Auth exitosos para: " + usuarioInput);

                                                        Intent intent = new Intent(MainActivity.this, MapaActivity.class);
                                                        startActivity(intent);
                                                        finish();
                                                    } else {
                                                        Toast.makeText(MainActivity.this, "Error al activar la sesión interna", Toast.LENGTH_SHORT).show();
                                                    }
                                                });
                                        return;
                                    }
                                }
                            }
                            Toast.makeText(this, getString(R.string.error_contrasenia_incorrecta), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, getString(R.string.error_usuario_no_existe), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("FirestoreLogin", "Error al conectar", e);
                        Toast.makeText(this, getString(R.string.error_conexion_servidor), Toast.LENGTH_SHORT).show();
                    });
        });

        tvRegistrate.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Registro.class);
            startActivity(intent);
        });
    }
}