package com.example.gasolineras_espana.ui.mapa;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.textfield.TextInputLayout;

import com.example.gasolineras_espana.BuildConfig;
import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterItem;
import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterRenderer;
import com.example.gasolineras_espana.ui.mapa.rutas.GeocodingApi;
import com.example.gasolineras_espana.ui.mapa.rutas.PolylineUtils;
import com.example.gasolineras_espana.ui.mapa.rutas.RoutesApi;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.clustering.ClusterManager;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RutaActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "RutaActivity";
    private static final double RADIO_KM = 5.0;

    private GoogleMap mMap;
    private MapaViewModel viewModel;

    // Localizacion
    private FusedLocationProviderClient fusedLocationClient;

    private final ActivityResultLauncher<String> locationPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) buscarYCalcular();
                        else Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
                    }
            );

    // ClusterManager para las gasolineras filtradas, igual que en MapaActivity
    private ClusterManager<GasolineraClusterItem> clusterManager;

    // Marcadores de origen y destino (pin verde y pin rojo)
    private Marker markerOrigen;
    private Marker markerDestino;

    // Polyline de la ruta calculada
    private Polyline polylineRuta;

    // Vistas del panel
    private AutoCompleteTextView etOrigen;
    private AutoCompleteTextView etDestino;
    private TextView txtEstado;
    private Button btnCalcular;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruta);

        etOrigen    = findViewById(R.id.etOrigen);
        etDestino   = findViewById(R.id.etDestino);
        txtEstado   = findViewById(R.id.txtRutaEstado);
        btnCalcular = findViewById(R.id.btnCalcularRuta);
        progress    = findViewById(R.id.progressRuta);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        TextInputLayout tilOrigen = findViewById(R.id.tilOrigen);
        if (tilOrigen != null) {
            tilOrigen.setEndIconOnClickListener(v -> etOrigen.setText("Mi ubicación"));
        }

        // Mismo ViewModel que MapaActivity: evita recargar las gasolineras
        viewModel = new ViewModelProvider(this).get(MapaViewModel.class);
        viewModel.cargarGasolineras();

        // Cuando las gasolineras esten listas, construimos la lista de municipios para el autocompletado
        viewModel.getGasolineras().observe(this, gasolineras -> {
            if (gasolineras != null && !gasolineras.isEmpty()) {
                configurarAutocompletado(gasolineras);
            }
        });

        btnCalcular.setOnClickListener(v -> buscarYCalcular());
        findViewById(R.id.btnLimpiarRuta).setOnClickListener(v -> limpiarTodo());

        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.mapRuta);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    // Extrae los municipios unicos de las gasolineras y los mete en el adapter de autocompletado
    private void configurarAutocompletado(List<Gasolinera> gasolineras) {
        // TreeSet para obtener los nombres ordenados y sin duplicados automaticamente
        TreeSet<String> municipiosSet = new TreeSet<>();
        for (Gasolinera g : gasolineras) {
            if (g.getMunicipio() != null && !g.getMunicipio().trim().isEmpty()) {
                municipiosSet.add(g.getMunicipio().trim());
            }
        }

        List<String> municipios = new ArrayList<>(municipiosSet);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, municipios);

        // El mismo adapter sirve para los dos campos
        etOrigen.setAdapter(adapter);
        etDestino.setAdapter(adapter);

        Log.d(TAG, "Autocompletado listo con " + municipios.size() + " municipios");
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        // Vista inicial: España completa
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(40.4168, -3.7038), 5.5f));

        // Inicializamos el cluster manager con el mismo renderer personalizado que MapaActivity
        clusterManager = new ClusterManager<>(this, mMap);
        GasolineraClusterRenderer renderer = new GasolineraClusterRenderer(this, mMap, clusterManager);
        clusterManager.setRenderer(renderer);
        mMap.setOnCameraIdleListener(clusterManager);
        mMap.setOnMarkerClickListener(clusterManager);
    }

    // Lee los campos, geocodifica (o usa GPS) y calcula la ruta
    @SuppressLint("MissingPermission")
    private void buscarYCalcular() {
        String textoOrigen  = etOrigen.getText()  != null ? etOrigen.getText().toString().trim()  : "";
        String textoDestino = etDestino.getText() != null ? etDestino.getText().toString().trim() : "";

        if (textoOrigen.isEmpty() || textoDestino.isEmpty()) {
            Toast.makeText(this, "Escribe el origen y el destino", Toast.LENGTH_SHORT).show();
            return;
        }

        cerrarTeclado();

        if (textoOrigen.equalsIgnoreCase("Mi ubicación")) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
                return;
            }

            setUiCargando(true, "⏳ Obteniendo tu ubicación...");
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng miPosicion = new LatLng(location.getLatitude(), location.getLongitude());
                    realizarCalculoRuta(miPosicion, textoOrigen, textoDestino);
                } else {
                    setUiCargando(false, null);
                    Toast.makeText(this, "No se pudo obtener tu ubicación actual", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                setUiCargando(false, null);
                Toast.makeText(this, "Error obteniendo ubicación", Toast.LENGTH_SHORT).show();
            });
        } else {
            setUiCargando(true, "⏳ Buscando direcciones...");
            realizarCalculoRuta(null, textoOrigen, textoDestino);
        }
    }

    private void realizarCalculoRuta(LatLng origenGPS, String textoOrigen, String textoDestino) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            LatLng origen  = origenGPS != null ? origenGPS : GeocodingApi.geocodificar(textoOrigen,  BuildConfig.ROUTES_API_KEY);
            LatLng destino = GeocodingApi.geocodificar(textoDestino, BuildConfig.ROUTES_API_KEY);

            if (origen == null || destino == null) {
                runOnUiThread(() -> {
                    setUiCargando(false, null);
                    String fallido = origen == null ? textoOrigen : textoDestino;
                    mostrarEstado("❌ No se encontró: " + fallido);
                    Toast.makeText(this, "No se pudo localizar la dirección", Toast.LENGTH_LONG).show();
                });
                return;
            }

            runOnUiThread(() -> mostrarEstado("⏳ Calculando ruta..."));

            String encodedPolyline = RoutesApi.computeRoute(
                    origen.latitude,  origen.longitude,
                    destino.latitude, destino.longitude,
                    BuildConfig.ROUTES_API_KEY
            );

            runOnUiThread(() -> {
                setUiCargando(false, null);

                if (encodedPolyline == null) {
                    mostrarEstado("❌ No se pudo calcular la ruta");
                    Toast.makeText(this, "Error al calcular la ruta", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Marcadores de origen y destino
                colocarMarkerOrigen(origen, textoOrigen);
                colocarMarkerDestino(destino, textoDestino);

                // Polyline azul
                List<LatLng> puntosRuta = PolylineUtils.decode(encodedPolyline);
                dibujarPolyline(puntosRuta);

                // Gasolineras filtradas
                List<Gasolinera> todas = viewModel.getGasolineras().getValue();
                if (todas != null && !todas.isEmpty()) {
                    List<Gasolinera> cercanas = PolylineUtils.filtrarCercanas(todas, puntosRuta, RADIO_KM);
                    cargarEnCluster(cercanas);
                    mostrarEstado("✅ " + cercanas.size() + " gasolineras en ruta");
                } else {
                    mostrarEstado("✅ Ruta calculada (gasolineras cargando...)");
                }
            });
        });
        executor.shutdown();
    }

    // Carga las gasolineras filtradas en el cluster con los markers personalizados
    private void cargarEnCluster(List<Gasolinera> gasolineras) {
        if (clusterManager == null) return;

        clusterManager.clearItems();
        for (Gasolinera g : gasolineras) {
            if (g.getLat() != 0.0 && g.getLon() != 0.0) {
                clusterManager.addItem(new GasolineraClusterItem(g));
            }
        }
        clusterManager.cluster();
        Log.d(TAG, "Gasolineras en ruta cargadas en cluster: " + gasolineras.size());
    }

    private void colocarMarkerOrigen(LatLng punto, String etiqueta) {
        if (markerOrigen != null) markerOrigen.remove();
        markerOrigen = mMap.addMarker(new MarkerOptions()
                .position(punto)
                .title("Origen: " + etiqueta)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
    }

    private void colocarMarkerDestino(LatLng punto, String etiqueta) {
        if (markerDestino != null) markerDestino.remove();
        markerDestino = mMap.addMarker(new MarkerOptions()
                .position(punto)
                .title("Destino: " + etiqueta)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
    }

    // Dibuja la polyline azul y ajusta la camara para ver la ruta completa
    private void dibujarPolyline(List<LatLng> puntos) {
        if (polylineRuta != null) polylineRuta.remove();

        polylineRuta = mMap.addPolyline(new PolylineOptions()
                .addAll(puntos)
                .color(0xFF1565C0)
                .width(10f)
                .geodesic(true));

        if (!puntos.isEmpty()) {
            LatLngBounds.Builder bounds = new LatLngBounds.Builder();
            for (LatLng p : puntos) bounds.include(p);
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 80));
        }
    }

    // Limpia el mapa y resetea los campos
    private void limpiarTodo() {
        if (markerOrigen  != null) { markerOrigen.remove();  markerOrigen  = null; }
        if (markerDestino != null) { markerDestino.remove(); markerDestino = null; }
        if (polylineRuta  != null) { polylineRuta.remove();  polylineRuta  = null; }
        if (clusterManager != null) clusterManager.clearItems();

        etOrigen.setText("");
        etDestino.setText("");
        txtEstado.setVisibility(View.GONE);

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(40.4168, -3.7038), 5.5f));
    }

    private void setUiCargando(boolean cargando, String mensajeCarga) {
        progress.setVisibility(cargando ? View.VISIBLE : View.GONE);
        btnCalcular.setEnabled(!cargando);
        if (cargando && mensajeCarga != null) mostrarEstado(mensajeCarga);
    }

    private void mostrarEstado(String texto) {
        txtEstado.setText(texto);
        txtEstado.setVisibility(View.VISIBLE);
    }

    private void cerrarTeclado() {
        View foco = getCurrentFocus();
        if (foco != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(foco.getWindowToken(), 0);
        }
    }
}
