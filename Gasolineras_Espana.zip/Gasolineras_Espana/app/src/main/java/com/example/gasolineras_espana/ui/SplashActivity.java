package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.data.GasolinerasRepository;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Forzamos la descarga/carga en el repositorio
        // Esto comprobará si el archivo local existe y si es de hoy. Si no lo es, lo baja.
        GasolinerasRepository.getInstance().cargarDesdeLocalOInternet(this);

        // Transición a MapaActivity después de 3 segundos (3000 ms)
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MapaActivity.class));
            finish();
        }, 3000);
    }
}
