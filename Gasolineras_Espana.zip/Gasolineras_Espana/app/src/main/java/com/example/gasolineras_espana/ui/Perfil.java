package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Perfil extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String userId;
    private String nombreOriginal = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        FirebaseUser usuarioActual = mAuth.getCurrentUser();

        if (usuarioActual != null) {
            userId = usuarioActual.getUid();

            EditText etUsuario = findViewById(R.id.etUsuario);
            EditText etContraseniaAntigua = findViewById(R.id.etContraseniaAntigua);
            EditText etContraseniaNueva = findViewById(R.id.etContraseniaNueva);
            AutoCompleteTextView atvProvincia = findViewById(R.id.atvProvincia);
            AutoCompleteTextView atvMunicipio = findViewById(R.id.atvMunicipio);
            Spinner spnCombustible = findViewById(R.id.spnCombustible);
            Button btnConfirmarCambios = findViewById(R.id.btnConfirmarCambios);
            Button btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
            ArrayAdapter<CharSequence> adapter = (ArrayAdapter<CharSequence>) spnCombustible.getAdapter();

            // 1. CARGAR DATOS
            db.collection("usuarios").document(userId).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            nombreOriginal = documentSnapshot.getString("usuario");
                            String provincia = documentSnapshot.getString("provincia");
                            String municipio = documentSnapshot.getString("municipio");
                            String combustibleFavorito = documentSnapshot.getString("combustible_fav");

                            if (nombreOriginal == null || nombreOriginal.isEmpty()) {
                                nombreOriginal = usuarioActual.getDisplayName() != null ? usuarioActual.getDisplayName() : "";
                            }

                            etUsuario.setText(nombreOriginal);

                            // TIP ANDROID: Al usar AutoCompleteTextView, pasa 'false' para que no se despliegue el filtro al cargar el texto de golpe
                            atvProvincia.setText(provincia, false);
                            atvMunicipio.setText(municipio, false);

                            if (adapter != null && combustibleFavorito != null) {
                                int posicion = adapter.getPosition(combustibleFavorito);
                                spnCombustible.setSelection(posicion);
                            }
                        } else {
                            // RED DE SEGURIDAD 1: Si entra aquí, el usuario está logueado pero NO existe su documento en Firestore
                            Toast.makeText(Perfil.this, "Error: No existe ningún documento en la base de datos para este usuario (" + userId + ")", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        // RED DE SEGURIDAD 2: Error de permisos o de red directo de Firebase
                        Toast.makeText(Perfil.this, "Fallo en Firestore: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });

            // 2. LÓGICA AL PULSAR "CONFIRMAR CAMBIOS"
            btnConfirmarCambios.setOnClickListener(v -> {
                String nombre = etUsuario.getText().toString().trim();
                String provincia = atvProvincia.getText().toString().trim();
                String municipio = atvMunicipio.getText().toString().trim();
                String passAntigua = etContraseniaAntigua.getText().toString().trim();
                String passNueva = etContraseniaNueva.getText().toString().trim();
                String combustibleSeleccionado = spnCombustible.getSelectedItem().toString();

                if (nombre.isEmpty() || provincia.isEmpty() || municipio.isEmpty()) {
                    Toast.makeText(Perfil.this, "El usuario, provincia y municipio son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (passAntigua.isEmpty() && !passNueva.isEmpty()) {
                    Toast.makeText(Perfil.this, "Para cambiar la contraseña debes introducir tu contraseña actual", Toast.LENGTH_LONG).show();
                    return;
                }
                if (!passAntigua.isEmpty() && passNueva.isEmpty()) {
                    Toast.makeText(Perfil.this, "Introduce la nueva contraseña que deseas usar", Toast.LENGTH_LONG).show();
                    return;
                }

                boolean quiereCambiarPass = !passAntigua.isEmpty() && !passNueva.isEmpty();

                if (!nombre.equalsIgnoreCase(nombreOriginal)) {
                    db.collection("usuarios").whereEqualTo("usuario", nombre).get()
                            .addOnSuccessListener(queryDocumentSnapshots -> {
                                if (!queryDocumentSnapshots.isEmpty()) {
                                    Toast.makeText(Perfil.this, "Ese nombre de usuario ya está registrado", Toast.LENGTH_LONG).show();
                                } else {
                                    procesarPasswordYGuardado(usuarioActual, nombre, provincia, municipio, combustibleSeleccionado, quiereCambiarPass, passAntigua, passNueva);
                                }
                            })
                            .addOnFailureListener(e -> Toast.makeText(Perfil.this, "Error al comprobar el usuario", Toast.LENGTH_SHORT).show());
                } else {
                    procesarPasswordYGuardado(usuarioActual, nombre, provincia, municipio, combustibleSeleccionado, quiereCambiarPass, passAntigua, passNueva);
                }
            });

            btnCerrarSesion.setOnClickListener(v -> {
                mAuth.signOut();
                irAlLogin();
            });

        } else {
            // RED DE SEGURIDAD 3: Si entra aquí, mAuth.getCurrentUser() es null (No hay sesión iniciada)
            Toast.makeText(Perfil.this, "No hay ninguna sesión de usuario activa. Redirigiendo...", Toast.LENGTH_LONG).show();
            irAlLogin();
        }
    }

    private void procesarPasswordYGuardado(FirebaseUser user, String nombre, String provincia, String municipio, String combustible, boolean cambiarPass, String passAntigua, String passNueva) {
        if (cambiarPass) {
            AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), passAntigua);
            user.reauthenticate(credential).addOnCompleteListener(taskReauth -> {
                if (taskReauth.isSuccessful()) {
                    user.updatePassword(passNueva).addOnCompleteListener(taskCambioPass -> {
                        if (taskCambioPass.isSuccessful()) {
                            guardarDatosEnFirestore(nombre, provincia, municipio, combustible, true);
                        } else {
                            Toast.makeText(Perfil.this, "Error al actualizar contraseña (mínimo 6 caracteres)", Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    Toast.makeText(Perfil.this, "La contraseña actual introducida no es correcta", Toast.LENGTH_LONG).show();
                }
            });
        } else {
            guardarDatosEnFirestore(nombre, provincia, municipio, combustible, false);
        }
    }

    private void guardarDatosEnFirestore(String nombre, String provincia, String municipio, String combustible, boolean contraseñaCambiada) {
        Map<String, Object> datosUsuario = new HashMap<>();
        datosUsuario.put("usuario", nombre);
        datosUsuario.put("provincia", provincia);
        datosUsuario.put("municipio", municipio);
        datosUsuario.put("combustible_fav", combustible);

        db.collection("usuarios").document(userId).update(datosUsuario)
                .addOnSuccessListener(aVoid -> {
                    nombreOriginal = nombre;
                    Toast.makeText(Perfil.this, "¡Perfil actualizado correctamente!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Perfil.this, MapaActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(Perfil.this, "Error al guardar los datos: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
    private void irAlLogin() {
        Intent intent = new Intent(Perfil.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}