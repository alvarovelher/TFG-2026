package com.example.gasolineras_espana.geojson;

import android.util.JsonReader;
import android.util.JsonToken;

import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.model.GeoJsonData;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/*
 * Clase encargada de parsear el GeoJSON recibido desde red de forma eficiente.
 *
 * Responsabilidad:
 * Convertir el contenido GeoJSON en objetos del modelo (GeoJsonData y Gasolinera)
 * usando parseo en streaming, evitando cargar todo el archivo en memoria.
 *
 * Funcionamiento:
 * - Utiliza JsonReader (android.util) para leer el JSON de forma secuencial.
 * - Lee el objeto raiz buscando:
 *      - fechaActualizacion
 *      - features (array principal de datos)
 * - Cada elemento de "features" (Feature en GeoJSON) representa una gasolinera.
 * - Se procesan mediante metodos auxiliares:
 *      - leerFeaturesArray(): recorre el array
 *      - leerFeature(): procesa cada elemento individual
 *      - leerProperties(): asigna los datos al modelo
 *      - leerGeometry(): extrae coordenadas
 *
 * Importante:
 * - En GeoJSON las coordenadas vienen en formato: [longitud, latitud]
 *   y se asignan correctamente:
 *      - primer valor -> longitud (lon) - segundo valor -> latitud (lat)
 *
 * - Los campos desconocidos se ignoran con reader.skipValue(), robustez ante cambios en el JSON.
 *
 * Metodos principales:
 * - parsearStream(InputStream): metodo publico que devuelve GeoJsonData.
 * - leerFeaturesArray(JsonReader): recorre el array de gasolineras.
 * - leerFeature(JsonReader): procesa una gasolinera.
 * - leerProperties(JsonReader, Gasolinera): mapea campos del JSON al modelo.
 * - leerGeometry(JsonReader, Gasolinera): obtiene coordenadas.
 * - leerDouble(JsonReader): convierte valores numericos o texto con coma.
 *
 * Dependencias:
 * - Gasolinera
 * - GeoJsonData
 *
 * Usada por:
 * - GeoJsonDownloader
 * - GasolinerasRepository
 */
public class GeoJsonParser {

     // Metodo principal del parser.
     // Recibe un InputStream y devuelve los datos ya convertidos a GeoJsonData.
    public GeoJsonData parsearStream(InputStream in) throws Exception {
        JsonReader reader = new JsonReader(new InputStreamReader(in, "UTF-8"));
        
        String fechaActualizacion = "";
        List<Gasolinera> listaGasolineras = new ArrayList<>();

        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if (name.equals("fechaActualizacion")) {
                fechaActualizacion = reader.nextString();
            } else if (name.equals("features")) {
                listaGasolineras = leerFeaturesArray(reader);
            } else {
                reader.skipValue(); // Nos saltamos los datos que no nos interesan
            }
        }
        reader.endObject();
        reader.close();

        return new GeoJsonData(fechaActualizacion, listaGasolineras);
    }


     // Recorre el array "features" del GeoJSON y crea la lista de gasolineras
    private List<Gasolinera> leerFeaturesArray(JsonReader reader) throws Exception {
        List<Gasolinera> gasolineras = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) {
            Gasolinera gas = leerFeature(reader);
            if (gas != null) {
                gasolineras.add(gas);
            }
        }
        reader.endArray();
        return gasolineras;
    }

    // Procesa una feature (una gasolinera) leyendo properties y geometry.
    private Gasolinera leerFeature(JsonReader reader) throws Exception {
        Gasolinera g = new Gasolinera();
        
        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if (name.equals("properties") && reader.peek() != JsonToken.NULL) {
                leerProperties(reader, g);
            } else if (name.equals("geometry") && reader.peek() != JsonToken.NULL) {
                leerGeometry(reader, g);
            } else {
                reader.skipValue();
            }
        }
        reader.endObject();
        return g;
    }

     // Mapea los campos JSON a los atributos del objeto Gasolinera.
    private void leerProperties(JsonReader reader, Gasolinera g) throws Exception {
        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if (reader.peek() == JsonToken.NULL) {
                reader.skipValue();
                continue;
            }
            // Mapeamos los datos del JSON al modelo
            switch (name) {
                case "id": g.setId(reader.nextString()); break;
                case "rotulo": g.setRotulo(reader.nextString()); break;
                case "direccion": g.setDireccion(reader.nextString()); break;
                case "municipio": g.setMunicipio(reader.nextString()); break;
                case "provincia": g.setProvincia(reader.nextString()); break;
                case "cp": g.setCp(reader.nextString()); break;
                case "horario": g.setHorario(reader.nextString()); break;
                case "p95": g.setP95(leerDouble(reader)); break;
                case "p98": g.setP98(leerDouble(reader)); break;
                case "diesel": g.setDiesel(leerDouble(reader)); break;
                case "dieselPremium": g.setDieselPremium(leerDouble(reader)); break;
                case "glp": g.setGlp(leerDouble(reader)); break;
                case "gnc": g.setGnc(leerDouble(reader)); break;
                case "gnl": g.setGnl(leerDouble(reader)); break;
                case "tipoVenta": g.setTipoVenta(reader.nextString()); break;
                default: reader.skipValue(); break; // si aparece un json key nuevo, se esquiva automagicamente
            }
        }
        reader.endObject();
    }

     // Extrae las coordenadas [lon, lat] del GeoJSON.
    private void leerGeometry(JsonReader reader, Gasolinera g) throws Exception {
        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if (name.equals("coordinates") && reader.peek() != JsonToken.NULL) {
                reader.beginArray();
                if (reader.hasNext()) g.setLon(reader.nextDouble());
                if (reader.hasNext()) g.setLat(reader.nextDouble());
                // Consumimos el resto de lat-lons por si tuvieran Z (altitud) 
                while (reader.hasNext()) reader.skipValue();
                reader.endArray();
            } else {
                reader.skipValue();
            }
        }
        reader.endObject();
    }

     // Convierte valores numericos o texto (con coma) a double. Da estructura al modelo
    private double leerDouble(JsonReader reader) throws Exception {
        JsonToken token = reader.peek();
        if (token == JsonToken.NUMBER) {
            return reader.nextDouble();
        } else if (token == JsonToken.STRING) {
            String texto = reader.nextString().trim();
            if (texto.isEmpty()) return -1.0;
            texto = texto.replace(",", "."); // Controlamos posibles comas
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                return -1.0;
            }
        } else {
            reader.skipValue();
            return -1.0;
        }
    }
}
