package com.example.gasolineras_espana.ui;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import com.example.gasolineras_espana.R;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.example.gasolineras_espana.data.GasolinerasRepository;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/*
 * Activity de configuracion de la aplicacion.
 *
 * Responsabilidad:
 * Gestionar las preferencias del usuario, permisos del sistema y opciones
 * de visualizacion del mapa.
 *
 * Funcionamiento:
 * - Permite activar/desactivar notificaciones y configurar su comportamiento.
 * - Gestiona permisos de ubicacion y notificaciones.
 * - Cambiar el tipo de mapa y mostrar precios en los marcadores.
 * - Muestra informacion sobre la ultima actualizacion de datos.
 * - Ofrece herramientas de mantenimiento como borrar cache local.
 *
 * Persistencia:
 * - Usa SharedPreferences ("OpcionesGasolineras") para almacenar configuraciones.
 *
 */


public class SettingsActivity extends AppCompatActivity {

    private TextView tvEstadoUbicacion, tvUltimaActualizacion;
    private SwitchMaterial switchMostrarPrecios;
    private Spinner spinnerTipoMapa;

    private SharedPreferences prefs;

    private final ActivityResultLauncher<String> requestLocationLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), isGranted -> checkPermissions()
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbarSettings);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        prefs = getSharedPreferences("OpcionesGasolineras", Context.MODE_PRIVATE);

        iniciarVistas();
        listeners();
        cargarPreferencias();
        actualizarInfoDatos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    private void iniciarVistas() {
        tvEstadoUbicacion = findViewById(R.id.tvEstadoUbicacion);
        tvUltimaActualizacion = findViewById(R.id.tvUltimaActualizacion);

        switchMostrarPrecios = findViewById(R.id.switchMostrarPrecios);
        spinnerTipoMapa = findViewById(R.id.spinnerTipoMapa);

        // Cargamos el array desde strings.xml en lugar de hardcodearlo en Java
        String[] tiposMapa = getResources().getStringArray(R.array.tipos_mapa_array);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tiposMapa);
        spinnerTipoMapa.setAdapter(adapter);
    }

    private void listeners() {
        findViewById(R.id.layoutPermisoUbicacion).setOnClickListener(v -> solicitarPermisoUbicacion());

        switchMostrarPrecios.setOnCheckedChangeListener((buttonView, isChecked) -> guardarPreferencias());

        spinnerTipoMapa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                guardarPreferencias();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        findViewById(R.id.btnActualizarAhora).setOnClickListener(v -> forzarActualizacion());
        findViewById(R.id.btnBorrarCache).setOnClickListener(v -> borrarCacheLocal());
    }

    private void cargarPreferencias() {
        switchMostrarPrecios.setChecked(prefs.getBoolean("pref_mapa_precios", true));
        spinnerTipoMapa.setSelection(prefs.getInt("pref_mapa_tipo", 0));
    }

    private void guardarPreferencias() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("pref_mapa_precios", switchMostrarPrecios.isChecked());
        editor.putInt("pref_mapa_tipo", spinnerTipoMapa.getSelectedItemPosition());
        editor.apply();

        // Si hay modificaciones, avisamos al mapa que debe refrescar
        prefs.edit().putBoolean("mapa_necesita_refresco", true).apply();
    }

    private void checkPermissions() {
        // Ubicación
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            tvEstadoUbicacion.setText(getString(R.string.settings_permiso_concedido));
            tvEstadoUbicacion.setTextColor(ContextCompat.getColor(this, R.color.color_permiso_concedido));
        } else {
            tvEstadoUbicacion.setText(getString(R.string.settings_permiso_denegado));
            tvEstadoUbicacion.setTextColor(ContextCompat.getColor(this, R.color.color_permiso_denegado));
        }
    }

    private void solicitarPermisoUbicacion() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                abrirAjustesApp();
            } else {
                requestLocationLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        } else {
            Toast.makeText(this, getString(R.string.settings_permiso_ubicacion_ya_concedido), Toast.LENGTH_SHORT).show();
        }
    }


    private void abrirAjustesApp() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    private void actualizarInfoDatos() {
        File f = new File(getFilesDir(), "gasolineras_local.geojson");
        if (f.exists()) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
            String fecha = dateFormat.format(new Date(f.lastModified()));
            tvUltimaActualizacion.setText(getString(R.string.settings_datos_ultima_act, fecha));
        } else {
            tvUltimaActualizacion.setText(getString(R.string.settings_datos_ultima_act, getString(R.string.settings_datos_nunca)));
        }
    }

    private void forzarActualizacion() {
        Button btn = findViewById(R.id.btnActualizarAhora);
        btn.setEnabled(false);
        btn.setText(getString(R.string.settings_actualizando));

        GasolinerasRepository repo = GasolinerasRepository.getInstance();
        
        // Observamos el estado de carga para saber cuando termina
        repo.getCargando().observe(this, cargando -> {
            if (!cargando && !btn.isEnabled()) {
                btn.setEnabled(true);
                btn.setText(getString(R.string.settings_btn_actualizar));
                actualizarInfoDatos();
                Toast.makeText(this, getString(R.string.settings_datos_actualizados), Toast.LENGTH_SHORT).show();
            }
        });

        repo.cargarDesdeLocalOInternet(this, true);
    }

    private void borrarCacheLocal() {
        File f = new File(getFilesDir(), "gasolineras_local.geojson");
        if (f.exists() && f.delete()) {
            actualizarInfoDatos();
            Toast.makeText(this, getString(R.string.settings_cache_borrada), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, getString(R.string.settings_cache_vacia), Toast.LENGTH_SHORT).show();
        }
    }
}
