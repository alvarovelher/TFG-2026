package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.ui.mapa.DetalleActivity;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.example.gasolineras_espana.ui.mapa.MapaViewModel;
import com.example.gasolineras_espana.utils.FavoritosAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class Favoritos extends AppCompatActivity {
    private RecyclerView rvFavoritos;
    private FavoritosAdapter adapter;
    private List<Gasolinera> listaAMostrar = new ArrayList<>();
    private MapaViewModel viewModel;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);

        // 1. Inicializar Firebase y Vistas
        db = FirebaseFirestore.getInstance();
        rvFavoritos = findViewById(R.id.rvFavoritos);
        rvFavoritos.setLayoutManager(new LinearLayoutManager(this));

        // 2. Inicializar el Adapter antes que el ViewModel
        adapter = new FavoritosAdapter(listaAMostrar, g -> {
            Intent intent = new Intent(this, DetalleActivity.class);

            // Pasamos todos los datos que DetalleActivity necesita
            intent.putExtra(DetalleActivity.EXTRA_ID, g.getId());
            intent.putExtra(DetalleActivity.EXTRA_ROTULO, g.getRotulo());
            intent.putExtra(DetalleActivity.EXTRA_DIRECCION, g.getDireccion());
            intent.putExtra(DetalleActivity.EXTRA_MUNICIPIO, g.getMunicipio());
            intent.putExtra(DetalleActivity.EXTRA_HORARIO, g.getHorario());
            intent.putExtra(DetalleActivity.EXTRA_LAT, g.getLat());
            intent.putExtra(DetalleActivity.EXTRA_LON, g.getLon());

            // Construimos el String de precios igual que en el Mapa
            StringBuilder precios = new StringBuilder();
            if(g.getP95() > 0)           precios.append("🟢 Sin Plomo 95:\t").append(g.getP95()).append(" €\n");
            if(g.getP98() > 0)           precios.append("⚫ Sin Plomo 98:\t").append(g.getP98()).append(" €\n");
            if(g.getDiesel() > 0)        precios.append("🟡 Diesel:\t").append(g.getDiesel()).append(" €\n");
            if(g.getDieselPremium() > 0) precios.append("🔵 Diesel+:\t").append(g.getDieselPremium()).append(" €\n");
            if(g.getGlp() > 0)           precios.append("🟠 GLP:\t").append(g.getGlp()).append(" €\n");
            if(g.getGnc() > 0)           precios.append("🔵 GNC:\t").append(g.getGnc()).append(" €\n");

            String misPrecios = precios.toString().trim();
            if(misPrecios.isEmpty()) misPrecios = "Precios no disponibles";

            intent.putExtra(DetalleActivity.EXTRA_PRECIOS, misPrecios);

            startActivity(intent);
        });
        rvFavoritos.setAdapter(adapter);

        // 3. Inicializar ViewModel
        viewModel = new ViewModelProvider(this).get(MapaViewModel.class);

        // 4. Configurar el Observador
        viewModel.getGasolineras().observe(this, todas -> {
            if (todas != null && !todas.isEmpty()) {
                // Cada vez que los datos de la API cambien o lleguen, refrescamos favoritos
                cargarFavoritosDeFirestore();
            }
        });

        // 5. Cargar datos
        viewModel.cargarGasolineras();
        BottomNavigationView bottomNav = findViewById(R.id.menuInferior);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_mapa) {
                startActivity(new Intent(Favoritos.this, com.example.gasolineras_espana.ui.mapa.MapaActivity.class));
            } else if (id == R.id.nav_favoritos) {
                return true;
            } else if (id == R.id.nav_ajustes) {
                startActivity(new Intent(Favoritos.this, com.example.gasolineras_espana.ui.SettingsActivity.class));
            }
            return false;
        });
    }

    private void cargarFavoritosDeFirestore() {
        String userId = getSharedPreferences("SesionUsuario", MODE_PRIVATE).getString("userId", null);

        db.collection("usuarios").document(userId).get().addOnSuccessListener(doc -> {
            if (doc.exists()) {
                List<String> idsFavoritos = (List<String>) doc.get("id_gasolineras");
                if (idsFavoritos != null && viewModel.getGasolineras().getValue() != null) {
                    filtrarGasolineras(idsFavoritos, viewModel.getGasolineras().getValue());
                }
            }
        });
    }

    private void filtrarGasolineras(List<String> idsFavs, List<Gasolinera> todas) {
        // Solo procesamos si hay cambios reales para no saturar la CPU
        List<Gasolinera> nuevaLista = new ArrayList<>();
        for (Gasolinera g : todas) {
            if (idsFavs.contains(g.getId())) {
                nuevaLista.add(g);
            }
        }

        // Solo actualizamos el adapter si la lista ha cambiado de tamaño
        // o si es la primera vez, para evitar refrescos infinitos.
        if (nuevaLista.size() != listaAMostrar.size()) {
            listaAMostrar.clear();
            listaAMostrar.addAll(nuevaLista);
            adapter.notifyDataSetChanged();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Cada vez que la pantalla vuelve a estar en primer plano, refrescamos desde Firestore
        if (viewModel.getGasolineras().getValue() != null) {
            cargarFavoritosDeFirestore();
        }
    }
}