package com.example.gasolineras_espana.ui.mapa.cluster;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.utils.BrandUtils;

import android.graphics.drawable.Drawable;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;

public class GasolineraClusterRenderer extends DefaultClusterRenderer<GasolineraClusterItem> {

    // Umbral de accion: mas grande que este numero indica que estamos cerca "ZOOM IN"
    public static final float ZOOM_THRESHOLD = 11.5f;

    private final Context context;
    private final IconGenerator iconGenerator;
    private final View markerView;
    private final ImageView imgLogo;
    private final TextView txtPrecios;

    // Tenemos que guardar la referencia al mapa para preguntarle en todo momento el zoom
    private final GoogleMap map;

    // Cache en memoria ampliada a 800 para evitar expulsar y regenerar masivamente al hacer zoom/pan
    private final LruCache<String, BitmapDescriptor> markerCache = new LruCache<>(800);

    public GasolineraClusterRenderer(Context context, GoogleMap map, ClusterManager<GasolineraClusterItem> clusterManager) {
        super(context, map, clusterManager);
        this.context = context;
        this.map = map;

        // Preparamos nuestro generador de imagenes virtuales (IconGenerator)
        this.iconGenerator = new IconGenerator(context);
        
        // Lo ponemos transparente por defecto para que no dibuje texturas extrañas
        this.iconGenerator.setBackground(null);

        // Inflamos (abrimos) nuestro XML UNA SOLA VEZ para reciclarlo y no saturar la CPU
        this.markerView = LayoutInflater.from(context).inflate(R.layout.item_marker_precio, null);
        this.imgLogo = markerView.findViewById(R.id.imgLogo);
        this.txtPrecios = markerView.findViewById(R.id.txtPreciosMarker);

        // Le pegamos nuestro XML al IconGenerator
        this.iconGenerator.setContentView(markerView);
        
        // Configuramos para que no agrupe en clúster si hay menos de 5 cerca
        setMinClusterSize(5); 
    }

    private boolean isPricesEnabled() {
        return context.getSharedPreferences("OpcionesGasolineras", Context.MODE_PRIVATE).getBoolean("pref_mapa_precios", true);
    }

    // Genera el icono según el zoom, usando caché para no repetir trabajo pesado.
    private BitmapDescriptor getDynamicMarkerIcon(Gasolinera gas, int logoRes, float zoomActual) {
        boolean showPrices = isPricesEnabled();
        
        if (zoomActual >= ZOOM_THRESHOLD) {
            return getFullIcon(gas, logoRes, showPrices);
        } else {
            return getSmallIcon(logoRes);
        }
    }

    private BitmapDescriptor getFullIcon(Gasolinera gas, int logoRes, boolean showPrices) {
        String cacheKey = "full_" + gas.getId() + "_" + showPrices;
        BitmapDescriptor cached = markerCache.get(cacheKey);
        if (cached != null) return cached;

        // Configurar la vista del marcador
        imgLogo.setImageResource(logoRes);
        if (showPrices) {
            String p95 = gas.getP95() > 0 ? String.valueOf(gas.getP95()) : "--";
            String pD = gas.getDiesel() > 0 ? String.valueOf(gas.getDiesel()) : "--";
            txtPrecios.setText(String.format("95: %s\nD: %s", p95, pD));
            txtPrecios.setVisibility(View.VISIBLE);
        } else {
            txtPrecios.setVisibility(View.GONE);
        }

        BitmapDescriptor icon = BitmapDescriptorFactory.fromBitmap(iconGenerator.makeIcon());
        markerCache.put(cacheKey, icon);
        return icon;
    }

    private BitmapDescriptor getSmallIcon(int logoRes) {
        String cacheKey = "small_" + logoRes;
        BitmapDescriptor cached = markerCache.get(cacheKey);
        if (cached != null) return cached;

        // Crear un icono simple de 32dp
        int size = (int) (32 * context.getResources().getDisplayMetrics().density);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
        Drawable drawable = androidx.core.content.ContextCompat.getDrawable(context, logoRes);
        
        if (drawable != null) {
            drawable.setBounds(0, 0, size, size);
            drawable.draw(canvas);
        }

        BitmapDescriptor icon = BitmapDescriptorFactory.fromBitmap(bitmap);
        markerCache.put(cacheKey, icon);
        return icon;
    }

    // Este metodo se llama para dibujar un ítem individual ANTES de ponerlo en el mapa (no un grupo)
    @Override
    protected void onBeforeClusterItemRendered(@NonNull GasolineraClusterItem item, @NonNull MarkerOptions markerOptions) {
        Gasolinera gas = item.getGasolinera();
        int logoRes = BrandUtils.getLogoResId(gas.getRotulo());
        float zoomActual = map.getCameraPosition().zoom;

        // Generamos el icono segun el zoom y los datos de la gasolinera
        markerOptions.icon(getDynamicMarkerIcon(gas, logoRes, zoomActual));

        super.onBeforeClusterItemRendered(item, markerOptions);
    }

    // Si la posición ya existía pero DEBE ACTUALIZARSE visualmente porque movimos el zoom del mapa
    @Override
    protected void onClusterItemUpdated(@NonNull GasolineraClusterItem item, @NonNull com.google.android.gms.maps.model.Marker marker) {
        Gasolinera gas = item.getGasolinera();
        int logoRes = BrandUtils.getLogoResId(gas.getRotulo());
        float zoomActual = map.getCameraPosition().zoom;

        // Solo llamamos a setIcon si es necesario necesario, el caché se ocupa de devolverlo de forma rapida.
        // ClusterManager puede llamar a este método, reusando el cache
        BitmapDescriptor icon = getDynamicMarkerIcon(gas, logoRes, zoomActual);
        marker.setIcon(icon);
    }
}
