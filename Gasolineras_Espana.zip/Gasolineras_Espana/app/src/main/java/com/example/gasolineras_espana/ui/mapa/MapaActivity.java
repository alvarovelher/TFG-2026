package com.example.gasolineras_espana.ui.mapa;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import java.util.ArrayList;
import java.util.List;

import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterItem;
import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterRenderer;
import com.example.gasolineras_espana.ui.mapa.rutas.RutaActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.maps.android.clustering.ClusterManager;


/*
 * Activity principal que muestra el mapa de gasolineras.
 *
 * Responsabilidad:
 * Gestionar la visualizacion del mapa, la ubicacion del usuario,
 * el clustering de gasolineras y la interaccion con la interfaz.
 *
 * Funcionamiento:
 * - Inicializa el mapa y configura sus opciones visuales.
 * - Observa el ViewModel para recibir los datos de gasolineras.
 * - Representa las gasolineras mediante clustering para mejorar rendimiento.
 * - Gestiona permisos de ubicacion con el sistema moderno de Android.
 * - Permite interactuar con los marcadores para ver detalles.
 *
 * Dependencias:
 * - MapaViewModel
 * - ClusterManager (Google Maps Utils)
 * - GasolineraClusterRenderer
 *
 * Es la capa de presentacion dentro del patron MVVM.
 */


public class MapaActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "MAPA_CLUSTER";

    private GoogleMap mMap;
    private ClusterManager<GasolineraClusterItem> clusterManager;
    private GasolineraClusterRenderer clusterRenderer;

    // Intermediario entre UI y datos
    private MapaViewModel viewModel;

    // Lista completa de gasolineras (sin filtrar). El viewport filter extrae el subconjunto visible.
    private List<Gasolinera> todasLasGasolineras = new ArrayList<>();

    // Maximo de marcadores a renderizar cuando el zoom es muy bajo (vista de pais)
    private static final int MAX_MARKERS_ZOOM_BAJO = 300;
    // Zoom a partir del cual aplicamos el limite de marcadores
    private static final float ZOOM_LIMITE = 8.0f;

    // Servicio de google para obtener la ubicacion del usuario
    private FusedLocationProviderClient fusedLocationClient;
    private boolean primeraUbicacionCentrada = false;

    // Lanzador de permisos: si el usuario acepta, activamos su ubicacion en el mapa
    private final ActivityResultLauncher<String> locationPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            activarUbicacionUsuario();
                            moverCamaraAMiUbicacionForzada();
                        } else {
                            Toast.makeText(this, getString(R.string.toast_permiso_ubicacion_denegado), Toast.LENGTH_SHORT).show();
                        }
                    }
            );

    @Override
    protected void onResume() {
        super.onResume();
        if (mMap != null) {
            aplicarPreferenciasVisuales();
        }
    }

    private void aplicarPreferenciasVisuales() {
        android.content.SharedPreferences prefs = getSharedPreferences("OpcionesGasolineras", android.content.Context.MODE_PRIVATE);
        
        int mapType = prefs.getInt("pref_mapa_tipo", 0);
        switch (mapType) {
            case 1: mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE); break;
            case 2: mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID); break;
            default: mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); break;
        }

        if (prefs.getBoolean("mapa_necesita_refresco", false)) {
            prefs.edit().putBoolean("mapa_necesita_refresco", false).apply();
            if (viewModel != null && viewModel.getGasolineras().getValue() != null) {
                // Vaciamos la caché del renderer para que los marcadores se redibuden con la nueva preferencia
                if (clusterRenderer != null) clusterRenderer.clearCache();
                actualizarClusterPorViewport();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa); 

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // El ViewModel sobrevive a los giros de pantalla, asi no recargamos datos innecesariamente
        viewModel = new ViewModelProvider(this).get(MapaViewModel.class);

        // FAB de ubicacion: centra el mapa en donde esta el usuario
        FloatingActionButton btnMiUbicacion = findViewById(R.id.btnMiUbicacion);
        if (btnMiUbicacion != null) {
            btnMiUbicacion.setOnClickListener(v -> {
                comprobarPermisoUbicacion();
                moverCamaraAMiUbicacionForzada();
            });
        }

        // FAB de ruta: abre la pantalla de calculo de ruta con gasolineras
        FloatingActionButton btnRuta = findViewById(R.id.btnRuta);
        if (btnRuta != null) {
            btnRuta.setOnClickListener(v ->
                startActivity(new Intent(MapaActivity.this, RutaActivity.class)));
        }

        // Busca el mapa en el layout y cuando esté cargado llama a onMapReady para poder usarlo
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Cuando el ViewModel tenga las gasolineras listas, guardamos la lista completa
        // y actualizamos el cluster con las visibles en ese momento
        viewModel.getGasolineras().observe(this, gasolineras -> {
            List<com.example.gasolineras_espana.model.Gasolinera> filtradas = com.example.gasolineras_espana.utils.FiltrosGasolineras.aplicarFiltros(
                gasolineras, null, null, 0, null, 0, false
            );
            todasLasGasolineras = filtradas;
            actualizarClusterPorViewport();
        });

        viewModel.cargarGasolineras();

        BottomNavigationView bottomNav = findViewById(R.id.menuInferior);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_mapa) {
                // Ya estás en el mapa o recárgalo
                return true;
            } else if (id == R.id.nav_favoritos) {
                startActivity(new Intent(MapaActivity.this, com.example.gasolineras_espana.ui.Favoritos.class));
                return true;
            } else if (id == R.id.nav_ajustes) {
                startActivity(new Intent(MapaActivity.this, com.example.gasolineras_espana.ui.SettingsActivity.class));
            }
            return false;
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Configura la interfaz del mapa: activa zoom y brújula, y quita el botón de ubicación (Uso uno configurado, el de serie tapaba info)
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(false); // usamos nuestro propio FAB

        // Vista inicial centrada en Espana
        LatLng espana = new LatLng(40.4168, -3.7038);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(espana, 5.5f));

        aplicarPreferenciasVisuales();
        comprobarPermisoUbicacion();

        // Configurar el cluster manager con nuestro renderer personalizado
        clusterManager = new ClusterManager<>(this, mMap);
        clusterRenderer = new GasolineraClusterRenderer(this, mMap, clusterManager);
        clusterManager.setRenderer(clusterRenderer);

        // El cluster necesita escuchar los eventos de camara para reagrupar al hacer zoom
        // Encadenamos: primero el ClusterManager procesa el idle, luego filtramos por viewport
        mMap.setOnCameraIdleListener(() -> {
            clusterManager.onCameraIdle();
            actualizarClusterPorViewport();
        });
        mMap.setOnMarkerClickListener(clusterManager);

        // Click en un marcador individual: abrir pantalla de detalle
        clusterManager.setOnClusterItemClickListener(item -> {
            Gasolinera g = item.getGasolinera();
            
            Intent intent = new Intent(MapaActivity.this, DetalleActivity.class);
            intent.putExtra(DetalleActivity.EXTRA_ROTULO, g.getRotulo());
            intent.putExtra(DetalleActivity.EXTRA_DIRECCION, g.getDireccion());
            intent.putExtra(DetalleActivity.EXTRA_MUNICIPIO, g.getMunicipio());
            intent.putExtra(DetalleActivity.EXTRA_HORARIO, g.getHorario());
            intent.putExtra(DetalleActivity.EXTRA_LAT, g.getLat());
            intent.putExtra(DetalleActivity.EXTRA_LON, g.getLon());
            intent.putExtra(DetalleActivity.EXTRA_ID, g.getId());

            // Bloque de precios con iconos por tipo de combustible (colores estándar UE)
            StringBuilder precios = new StringBuilder();
            if(g.getP95() > 0)           precios.append(getString(R.string.precio_p95,           String.valueOf(g.getP95()))).append("\n");
            if(g.getP98() > 0)           precios.append(getString(R.string.precio_p98,           String.valueOf(g.getP98()))).append("\n");
            if(g.getDiesel() > 0)        precios.append(getString(R.string.precio_diesel,        String.valueOf(g.getDiesel()))).append("\n");
            if(g.getDieselPremium() > 0) precios.append(getString(R.string.precio_diesel_premium, String.valueOf(g.getDieselPremium()))).append("\n");
            if(g.getGlp() > 0)           precios.append(getString(R.string.precio_glp,           String.valueOf(g.getGlp()))).append("\n");
            if(g.getGnc() > 0)           precios.append(getString(R.string.precio_gnc,           String.valueOf(g.getGnc()))).append("\n");

            String misPrecios = precios.toString().trim();
            if(misPrecios.isEmpty()) misPrecios = getString(R.string.text_precios_no_disponibles);

            intent.putExtra(DetalleActivity.EXTRA_PRECIOS, misPrecios);
            startActivity(intent);

            return true; // true = consumimos el evento, evitamos comportamiento por defecto del mapa
        });

        // Si las gasolineras ya estaban cargadas antes de que el mapa estuviera listo, cargamos las visibles
        List<Gasolinera> yaCargadas = viewModel.getGasolineras().getValue();
        if (yaCargadas != null && !yaCargadas.isEmpty()) {
            List<Gasolinera> filtradas = com.example.gasolineras_espana.utils.FiltrosGasolineras.aplicarFiltros(
                yaCargadas, null, null, 0, null, 0, false
            );
            todasLasGasolineras = filtradas;
            actualizarClusterPorViewport();
        }
    }

    /*
     * Filtra todasLasGasolineras por el area visible en camara (bounds + 20% de margen)
     * y actualiza el cluster solo con ese subconjunto.
     * A zoom bajo aplica un techo de MAX_MARKERS_ZOOM_BAJO marcadores para evitar lag.
     */
    private void actualizarClusterPorViewport() {
        if (mMap == null || clusterManager == null || todasLasGasolineras == null) return;

        com.google.android.gms.maps.model.LatLngBounds bounds = mMap.getProjection().getVisibleRegion().latLngBounds;
        float zoom = mMap.getCameraPosition().zoom;

        // Ampliamos los limites un 20% para precargar gasolineras justo fuera del borde visible
        double latSpan = (bounds.northeast.latitude  - bounds.southwest.latitude)  * 0.2;
        double lngSpan = (bounds.northeast.longitude - bounds.southwest.longitude) * 0.2;

        double minLat = bounds.southwest.latitude  - latSpan;
        double maxLat = bounds.northeast.latitude  + latSpan;
        double minLng = bounds.southwest.longitude - lngSpan;
        double maxLng = bounds.northeast.longitude + lngSpan;

        List<Gasolinera> visibles = new ArrayList<>();
        for (Gasolinera g : todasLasGasolineras) {
            if (g.getLat() >= minLat && g.getLat() <= maxLat
                    && g.getLon() >= minLng && g.getLon() <= maxLng) {
                visibles.add(g);
            }
        }

        // A zoom muy bajo (vista de pais/region), limitamos para no saturar el render
        if (zoom < ZOOM_LIMITE && visibles.size() > MAX_MARKERS_ZOOM_BAJO) {
            int step = visibles.size() / MAX_MARKERS_ZOOM_BAJO;
            List<Gasolinera> muestreo = new ArrayList<>(MAX_MARKERS_ZOOM_BAJO);
            for (int i = 0; i < visibles.size(); i += step) {
                muestreo.add(visibles.get(i));
                if (muestreo.size() >= MAX_MARKERS_ZOOM_BAJO) break;
            }
            visibles = muestreo;
        }

        cargarEnCluster(visibles);
    }

    private void cargarEnCluster(List<Gasolinera> gasolineras) {
        if (gasolineras == null || mMap == null || clusterManager == null) return;

        clusterManager.clearItems();
        for (Gasolinera g : gasolineras) {
            // Saltamos las que no tienen coordenadas validas
            if (g.getLat() != 0.0 && g.getLon() != 0.0) {
                clusterManager.addItem(new GasolineraClusterItem(g));
            }
        }
        clusterManager.cluster();
        Log.d(TAG, "Cargadas " + gasolineras.size() + " gasolineras en el cluster");
    }

    private void comprobarPermisoUbicacion() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            activarUbicacionUsuario();
        } else {
            // Si no tenemos permiso, lo pedimos con el launcher registrado en el campo de arriba
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    @SuppressLint("MissingPermission")
    private void activarUbicacionUsuario() {
        if (mMap == null) return;

        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(false); // usamos nuestro propio FAB

        // Solo centramos la camara la primera vez que abrimos el mapa
        if (!primeraUbicacionCentrada) {
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null && mMap != null && !primeraUbicacionCentrada) {
                    LatLng miPosicion = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(miPosicion, 14f));
                    primeraUbicacionCentrada = true;
                }
            });
        }
    }

    @SuppressLint("MissingPermission")
    private void moverCamaraAMiUbicacionForzada() {
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null && mMap != null) {
                LatLng miPosicion = new LatLng(location.getLatitude(), location.getLongitude());
                // animateCamera crentra el mapa en las coordenadas marcadas
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(miPosicion, 15f));
            }
        });
    }
}