package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.geojson.GeoJsonDownloader;
import com.example.gasolineras_espana.model.ConexionSQL;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.model.GasolineraDAO;
import com.example.gasolineras_espana.model.GeoJsonData;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        GasolineraDAO dao = new GasolineraDAO(this);
        cargarDatosYContinuar(dao);
    }

    private void cargarDatosYContinuar(GasolineraDAO dao) {

        ExecutorService executor = Executors.newSingleThreadExecutor();

        executor.execute(() -> {
            try {
                GeoJsonDownloader downloader = new GeoJsonDownloader();

                GeoJsonData data = downloader.descargarYParsear(
                        "https://raw.githubusercontent.com/MigMoy93/gasolineras-espana/main/gasolineras.geojson"
                );

                dao.abrirConexion();

                try {

                    for (Gasolinera g : data.getGasolineras()) {
                        dao.insertarGasolinera(g);
                    }

                } finally {
                    dao.cerrarConexion();
                }

                runOnUiThread(() -> {

                     Log.d("DB", "Carga finalizada: " + data.getGasolineras().size());
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
