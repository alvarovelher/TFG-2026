package com.example.gasolineras_espana.ui.mapa;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.utils.BrandUtils;


/*
 * Activity que muestra el detalle de una gasolinera.
 *
 * Responsabilidad:
 * Recibir los datos desde MapaActivity mediante Intent y mostrarlos en pantalla.
 *
 * Funcionamiento:
 * - Recupera los datos enviados (rotulo, direccion, precios, coordenadas).
 * - Rellena la interfaz con la informacion de la gasolinera.
 * - Muestra el logo correspondiente usando BrandUtils.
 * - Permite abrir Google Maps para navegar hasta la ubicacion.
 *
 */

public class DetalleActivity extends AppCompatActivity {

    // Etiquetas estaticas para enviarnos "paquetes" de datos a traves del Intent
    public static final String EXTRA_ROTULO = "extra_rotulo";
    public static final String EXTRA_DIRECCION = "extra_direccion";
    public static final String EXTRA_MUNICIPIO = "extra_municipio";
    public static final String EXTRA_HORARIO = "extra_horario";
    public static final String EXTRA_PRECIOS = "extra_precios";
    public static final String EXTRA_LAT = "extra_lat";
    public static final String EXTRA_LON = "extra_lon";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbarDetalle);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        // Atar los hilos entre XML (vistas) y nuestro codigo Java
        ImageView imgLogo = findViewById(R.id.imgDetalleLogoToolbar);
        TextView txtRotulo = findViewById(R.id.txtDetalleRotuloToolbar);
        TextView txtDireccion = findViewById(R.id.txtDetalleDireccion);
        TextView txtHorario = findViewById(R.id.txtDetalleHorario);
        TextView txtPrecios = findViewById(R.id.txtDetallePrecios);
        Button btnIrMaps = findViewById(R.id.btnIrMaps);

        // Recuperar el 'paquete' de datos que nos ha pasado MapaActivity al hacer click
        Intent intent = getIntent();
        String rotulo = intent.getStringExtra(EXTRA_ROTULO);
        String direccion = intent.getStringExtra(EXTRA_DIRECCION) + ", " + intent.getStringExtra(EXTRA_MUNICIPIO);
        String horario = intent.getStringExtra(EXTRA_HORARIO);
        String precios = intent.getStringExtra(EXTRA_PRECIOS);
        
        // Cuidado con coordenadas raras: 0.0 sera el seguro si algo falla al recibirlas
        double lat = intent.getDoubleExtra(EXTRA_LAT, 0.0);
        double lon = intent.getDoubleExtra(EXTRA_LON, 0.0);

        // Rellenamos el layout para que luzca bien
        txtRotulo.setText(rotulo != null ? rotulo : "Estación de Servicio");
        txtDireccion.setText(direccion);
        txtHorario.setText("⌚ " + (horario != null ? horario : "Sin especificar"));
        txtPrecios.setText(precios);

        // Llamamos a BrandUtils para obtener el logo correspondiente
        if (rotulo != null) {
            int recursoLogo = BrandUtils.getLogoResId(rotulo);
            imgLogo.setImageResource(recursoLogo);
        }

        // "Como llegar" mediante Google Maps
        btnIrMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Preparamos un link especial (schema google.navigation) que abre el modo coche
                Uri gmmIntentUri = Uri.parse("google.navigation:q=" + lat + "," + lon);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                // Aseguramos que se intente abrir con la app oficial de Google Maps
                mapIntent.setPackage("com.google.android.apps.maps");

                // Comprobamos si el usuario tiene google maps
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                } else {
                    // Si no la tiene, un  aviso y no crashea nada
                    Toast.makeText(DetalleActivity.this, "Necesitas instalar Google Maps :)", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
