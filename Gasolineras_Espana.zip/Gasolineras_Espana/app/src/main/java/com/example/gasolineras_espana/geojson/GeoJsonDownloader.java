package com.example.gasolineras_espana.geojson;

import com.example.gasolineras_espana.model.GeoJsonData;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/*
 * Clase que realiza una peticion HTTP GET al GeoJSON alojado en GitHub (raw)
 * y devuelve un objeto GeoJsonData con el contenido ya parseado.
 *
 * Responsabilidad:
 * Encargarse de descargar los datos desde la URL y transformarlos directamente
 * a objetos del modelo sin que otras clases tengan que preocuparse por la red.
 *
 * Funcionamiento:
 * - Abre una conexion HttpURLConnection contra la URL del GeoJSON.
 * - Configura timeouts de 15 segundos para evitar bloqueos.
 * - Si la respuesta es HTTP 200 (OK), obtiene el InputStream.
 * - El stream se pasa directamente al GeoJsonParser, evitando cargar todo el JSON en memoria (mas eficiente).
 *
 * - La ejecucion en segundo plano la gestiona el ExecutorService del Repository o el WorkManager (SyncWorker).
 *
 * Dependencias:
 * - GeoJsonParser: para parsear el contenido.
 * - GeoJsonData: objeto resultado.
 * - Usada por GasolinerasRepository como capa de acceso a datos remotos.
 */


public class GeoJsonDownloader {

    // Este metodo devuelve directamente un objeto GeoJsonData procesado
    // Asi evitamos almacenar megabytes de texto en un String, protegiendo la memoria RAM.
    public GeoJsonData descargarYParsear(String urlString) throws Exception {
        HttpURLConnection connection = null;

        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000); // 15 segundos maximo de espera de red
            connection.setReadTimeout(15000);
            connection.connect();

            // Buscamos obtener HTTP 200
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new Exception("Error HTTP: " + responseCode);
            }

            // Conseguimos el flujo de bits directamente desde internet
            InputStream inputStream = connection.getInputStream();
            
            // Le pasamos la conexion al parseador de GeoJSON
            GeoJsonParser parser = new GeoJsonParser();
            return parser.parsearStream(inputStream);

        } finally {
            // Siempre aseguramos cerrar la conexion para no agotar recursos
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
