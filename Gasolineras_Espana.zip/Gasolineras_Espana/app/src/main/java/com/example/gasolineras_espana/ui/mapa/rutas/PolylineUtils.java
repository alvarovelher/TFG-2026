package com.example.gasolineras_espana.ui.mapa.rutas;

import com.example.gasolineras_espana.model.Gasolinera;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase utilitaria para trabajar con polylines de Google Maps.
 *
 * Responsabilidad:
 * Convertir una polyline codificada (string comprimido) en una lista de
 * coordenadas LatLng utilizables en el mapa.
 *
 * Funcionamiento:
 * - Aplica el algoritmo de decodificacion de Google.
 * - Convierte el string en una secuencia de puntos geograficos.
 * - Devuelve una lista de LatLng que representa la ruta completa.
 *
 * Es necesaria para poder dibujar la ruta obtenida desde Routes API.
 */
public class PolylineUtils {

    // El algoritmo de Google usa este factor de escala para comprimir coordenadas
    private static final int PRECISION = 100000;

    /**
     * Decodifica una encoded polyline (formato Google) a una lista de coordenadas.
     * Mas info del algoritmo: https://developers.google.com/maps/documentation/utilities/polylinealgorithm
     */
    public static List<LatLng> decode(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0;
        int len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;

            // Decodifica la latitud
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int deltaLat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += deltaLat;

            shift = 0;
            result = 0;

            // Decodifica la longitud
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int deltaLng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += deltaLng;

            poly.add(new LatLng((double) lat / PRECISION, (double) lng / PRECISION));
        }

        return poly;
    }
}
