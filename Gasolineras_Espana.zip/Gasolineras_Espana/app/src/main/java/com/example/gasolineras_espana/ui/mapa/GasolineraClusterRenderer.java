package com.example.gasolineras_espana.ui.mapa;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.utils.BrandUtils;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;

public class GasolineraClusterRenderer extends DefaultClusterRenderer<GasolineraClusterItem> {

    // Umbral de accion: mas grande que este numero indica que estamos cerca "ZOOM IN"
    public static final float ZOOM_THRESHOLD = 11.5f;

    private final Context context;
    private final IconGenerator iconGenerator;
    private final View markerView;
    private final ImageView imgLogo;
    private final TextView txtPrecios;

    // Tenemos que guardar la referencia al mapa para preguntarle en todo momento el zoom
    private final GoogleMap map;

    // MAGIA DE RENDIMIENTO: Caché de 300 Bitmaps
    // Evita la regeneración y el cruce de datos al recargar la vista única (Bug de maps-utils)
    private final LruCache<String, BitmapDescriptor> markerCache = new LruCache<>(300);

    public GasolineraClusterRenderer(Context context, GoogleMap map, ClusterManager<GasolineraClusterItem> clusterManager) {
        super(context, map, clusterManager);
        this.context = context;
        this.map = map;

        // Preparamos nuestro generador de imagenes virtuales (IconGenerator)
        this.iconGenerator = new IconGenerator(context);
        
        // Lo ponemos transparente por defecto para que no dibuje texturas feas de fondo globo
        this.iconGenerator.setBackground(null);

        // Inflamos (abrimos) nuestro XML UNA SOLA VEZ para reciclarlo y no saturar la CPU
        this.markerView = LayoutInflater.from(context).inflate(R.layout.item_marker_precio, null);
        this.imgLogo = markerView.findViewById(R.id.imgLogo);
        this.txtPrecios = markerView.findViewById(R.id.txtPreciosMarker);

        // Le pegamos nuestro XML al IconGenerator
        this.iconGenerator.setContentView(markerView);
        
        // Configuramos para que no agrupe en clúster si hay menos de 5 muy cerquita
        setMinClusterSize(5); 
    }

    // ✨ Refactorización Mágica: Un único método centralizado para evitar código duplicado
    private BitmapDescriptor getDynamicMarkerIcon(Gasolinera gas, int logoRes, float zoomActual) {
        if (zoomActual >= ZOOM_THRESHOLD) {
            String cacheKey = "full_" + gas.getId(); // Nuestra llave maestra
            BitmapDescriptor cachedIcon = markerCache.get(cacheKey);

            if (cachedIcon != null) {
                // 🚀 SUPER RENDIMIENTO: ¡Acierto de caché! La imagen virtual ya existe.
                return cachedIcon;
            }

            // FALLO DE CACHÉ: Nos toca dibujar el layout complejo sincrónicamente.
            this.imgLogo.setImageResource(logoRes);
            String precio95 = gas.getP95() > 0 ? String.valueOf(gas.getP95()) : "--";
            String precioD = gas.getDiesel() > 0 ? String.valueOf(gas.getDiesel()) : "--";
            this.txtPrecios.setText("95: " + precio95 + "\nD: " + precioD);

            Bitmap iconBitmap = iconGenerator.makeIcon();
            BitmapDescriptor nuevoIcono = BitmapDescriptorFactory.fromBitmap(iconBitmap);
            
            // Guardamos en nuestro banco de la LruCache para la proxima vez que se mueva la pantalla
            markerCache.put(cacheKey, nuevoIcono);
            return nuevoIcono;

        } else {
            // ZOOM LEJANO -> Creamos un logo reducido a mano para que no quite visibilidad
            String cacheKey = "small_" + logoRes; // Compartido por todas las gasolineras de la misma marca
            BitmapDescriptor cachedIcon = markerCache.get(cacheKey);

            if (cachedIcon != null) {
                return cachedIcon; // Reutilizamos si ya encogimos este logo antes
            }

            // Calculamos 32dp reales dependiendo de la densidad de pantalla del móvil
            int sizePx = (int) (32 * context.getResources().getDisplayMetrics().density);
            
            // Creamos un lienzo invisible y dibujamos el Drawable original pero encogido
            Drawable drawable = androidx.core.content.ContextCompat.getDrawable(context, logoRes);
            Bitmap smallBitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(smallBitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);

            BitmapDescriptor nuevoIconoPequeño = BitmapDescriptorFactory.fromBitmap(smallBitmap);
            
            // Lo guardamos en caché para que las demás gasolineras lejos no tengan que recalcular su encogimiento
            markerCache.put(cacheKey, nuevoIconoPequeño);
            return nuevoIconoPequeño;
        }
    }

    // Este metodo se llama para dibujar un ítem individual ANTES de ponerlo en el mapa (no un grupo)
    @Override
    protected void onBeforeClusterItemRendered(@NonNull GasolineraClusterItem item, @NonNull MarkerOptions markerOptions) {
        Gasolinera gas = item.getGasolinera();
        int logoRes = BrandUtils.getLogoResId(gas.getRotulo());
        float zoomActual = map.getCameraPosition().zoom;

        // Se lo tragamos a nuestra única función inteligente
        markerOptions.icon(getDynamicMarkerIcon(gas, logoRes, zoomActual));

        super.onBeforeClusterItemRendered(item, markerOptions);
    }

    // Si la posición ya existía pero DEBE ACTUALIZARSE visualmente porque movimos el zoom del mapa
    @Override
    protected void onClusterItemUpdated(@NonNull GasolineraClusterItem item, @NonNull com.google.android.gms.maps.model.Marker marker) {
        Gasolinera gas = item.getGasolinera();
        int logoRes = BrandUtils.getLogoResId(gas.getRotulo());
        float zoomActual = map.getCameraPosition().zoom;

        // Misma invocación limpia, 0 duplicados
        marker.setIcon(getDynamicMarkerIcon(gas, logoRes, zoomActual));
    }
}
