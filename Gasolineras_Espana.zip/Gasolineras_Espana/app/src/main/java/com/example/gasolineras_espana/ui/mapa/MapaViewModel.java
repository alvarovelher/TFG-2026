package com.example.gasolineras_espana.ui.mapa;

import android.util.Log;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.gasolineras_espana.data.GasolinerasRepository;
import com.example.gasolineras_espana.model.Gasolinera;

import java.util.List;

/**
 * ViewModel del mapa dentro del patron MVVM (Model - View - ViewModel).
 *
 * Responsabilidad:
 * Hace de intermediario entre la Activity y el repositorio,
 * proporcionando los datos sin que la interfaz tenga que saber de donde vienen.
 *
 * Funcionamiento:
 * - Extiende AndroidViewModel para tener acceso al contexto de la aplicacion.
 * - Mantiene los datos en memoria aunque haya rotaciones de pantalla.
 * - Expone los datos con LiveData para que la UI los observe automaticamente.
 * - Toda la logica de datos se delega en GasolinerasRepository.
 *
 * Ventajas:
 * - Evita recargas innecesarias de datos.
 * - Mantiene la separacion entre la logica y UI.
 *
 * Dependencias:
 * - GasolinerasRepository
 *
 * Usada por:
 * - MapaActivity
 * - RutaActivity
 */
public class MapaViewModel extends AndroidViewModel {

    private final GasolinerasRepository repository = GasolinerasRepository.getInstance();

    public MapaViewModel(Application application) {
        super(application);
    }

    // Devuelve la lista observable de gasolineras.
    public LiveData<List<Gasolinera>> getGasolineras() {
        return repository.getGasolineras();
    }

    // Solicita la carga de datos al repositorio.
    public void cargarGasolineras() {
        repository.cargarGasolineras(getApplication());
    }

    // El hilo secundario ahora se encarga el Singleton Repository, asi que no hace falta cerrarlo desde aqui.
}