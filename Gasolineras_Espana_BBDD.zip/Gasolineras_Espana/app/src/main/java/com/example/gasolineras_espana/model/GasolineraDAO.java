package com.example.gasolineras_espana.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class GasolineraDAO {
    private ConexionSQL conexion;
    private SQLiteDatabase db;

    public GasolineraDAO(Context contexto) {
        conexion = new ConexionSQL(contexto);
    }

    public void abrirConexion() {
        db = conexion.getWritableDatabase();
    }

    public void cerrarConexion() {
        db.close();
    }

    public boolean insertarGasolinera(Gasolinera g){
        ContentValues valores = new ContentValues();
        valores.put("id_gasolinera",g.getId());
        valores.put("rotulo",g.getRotulo());
        valores.put("direccion",g.getDireccion());
        valores.put("municipio",g.getMunicipio());
        valores.put("provincia",g.getProvincia());
        valores.put("codigo_postal",g.getCp());
        valores.put("horario",g.getHorario());
        valores.put("latitud",g.getLat());
        valores.put("longitud",g.getLon());
        valores.put("precio_gasolina95",g.getP95());
        valores.put("precio_gasolina98",g.getP98());
        valores.put("precio_diesel",g.getDiesel());
        valores.put("precio_diesel_premium",g.getDieselPremium());
        valores.put("precio_glp",g.getGlp());
        valores.put("precio_gnc",g.getGnc());
        valores.put("precio_gnl",g.getGnl());

        Long id = db.insert("gasolineras",null,valores);
        boolean insertado = true;

        if(id == -1){
            insertado = false;
        }

        return insertado;
    }
}
