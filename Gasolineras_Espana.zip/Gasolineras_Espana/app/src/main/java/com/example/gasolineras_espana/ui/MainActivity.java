package com.example.gasolineras_espana.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // 1. Enlazamos los campos de texto y el botón
        EditText etUsuario = findViewById(R.id.etUsuario);
        EditText etContrasenia = findViewById(R.id.etContrasenia);
        Button btnLogin = findViewById(R.id.btnRegistro);
        TextView tvRegistrate = findViewById(R.id.tvRegistrate);

        // 2. Configuración del evento click para el inicio de sesión
        btnLogin.setOnClickListener(v -> {
            String usuarioInput = etUsuario.getText().toString().trim();
            String passInput = etContrasenia.getText().toString().trim();

            if (usuarioInput.isEmpty() || passInput.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_campos_vacios), Toast.LENGTH_SHORT).show();
                return;
            }

            // Consultamos Firestore para verificar las credenciales
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios")
                    .whereEqualTo("usuario", usuarioInput)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            // El usuario existe, comprobamos la contraseña
                            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                                String dbPass = doc.getString("contrasenia");
                                if (dbPass != null && dbPass.equals(passInput)) {
                                    // Login correcto: guardamos el ID del documento en SharedPreferences
                                    // para que DetalleActivity pueda identificar al usuario sin Firebase Auth
                                    getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
                                            .edit()
                                            .putString("userId", doc.getId())
                                            .apply();
                                    Log.d("FirestoreLogin", "Login exitoso para: " + usuarioInput);
                                    Intent intent = new Intent(MainActivity.this, MapaActivity.class);
                                    startActivity(intent);
                                    finish();
                                    return;
                                }
                            }
                            // Si salimos del bucle sin retornar, la pass está mal
                            Toast.makeText(this, getString(R.string.error_contrasenia_incorrecta), Toast.LENGTH_SHORT).show();
                        } else {
                            // El usuario no existe en la colección
                            Toast.makeText(this, getString(R.string.error_usuario_no_existe), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("FirestoreLogin", "Error al conectar", e);
                        Toast.makeText(this, getString(R.string.error_conexion_servidor), Toast.LENGTH_SHORT).show();
                    });
        });
        tvRegistrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Registro.class);
                startActivity(intent);
            }
        });
    }


}