package com.example.gasolineras_espana.utils;

import com.example.gasolineras_espana.model.Gasolinera;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase utilitaria para filtrar gasolineras segun distintos criterios.
 *
 * Responsabilidad:
 * Aplicar filtros sobre la lista completa de gasolineras y devolver solo
 * las que cumplen las condiciones indicadas.
 *
 * Funcionamiento:
 * - Filtra por compania o rotulo.
 * - Filtra por distancia minima desde el origen.
 * - Filtra por cercania a una ruta calculada.
 * - Usa la formula de Haversine para calcular distancias entre coordenadas.
 *
 */

public class FiltrosGasolineras {

    /**
     * Aplica multiples filtros a una lista de gasolineras en una sola pasada.
     * Esta clase permite reutilizacion de codigo tanto en el Mapa normal como en la Ruta.
     *
     * @param todas           Lista completa de gasolineras (ej. guardada en ViewModel)
     * @param compania        Rotulo de la compañia (null o vacio si no se filtra)
     * @param origen          Coordenadas de inicio de ruta (null si no se aplica filtro de origen)
     * @param minKmDesdeOrigen Distancia minima en KM desde el origen para mostrar gasolinera (0 si no se aplica)
     * @param ruta            Puntos de polyline (null si no estamos en modo ruta)
     * @param radioRutaKm     Distancia maxima de desvio permitida desde la ruta (aplicable si ruta != null)
     * @return Lista filtrada
     */
    public static List<Gasolinera> aplicarFiltros(
            List<Gasolinera> todas,
            String compania,
            LatLng origen,
            double minKmDesdeOrigen,
            List<LatLng> ruta,
            double radioRutaKm) {

        List<Gasolinera> resultado = new ArrayList<>();

        if (todas == null || todas.isEmpty()) return resultado;

        for (Gasolinera g : todas) {
            // Descartamos las que no tienen coordenadas
            if (g.getLat() == 0.0 && g.getLon() == 0.0) continue;

            // 1. Filtro de Compañia
            if (compania != null && !compania.trim().isEmpty()) {
                if (g.getRotulo() == null || !g.getRotulo().toUpperCase().contains(compania.toUpperCase())) {
                    continue; // No coincide con la marca preferida
                }
            }

            // 2. Filtro de Autonomia (Distancia minima desde Origen en linea recta)
            if (origen != null && minKmDesdeOrigen > 0) {
                double distanciaDesdeInicio = distanciaKm(origen.latitude, origen.longitude, g.getLat(), g.getLon());
                if (distanciaDesdeInicio < minKmDesdeOrigen) {
                    continue; // Esta muy cerca del origen, la saltamos
                }
            }

            // 3. Filtro de Ruta (Radio de desvio maximo)
            if (ruta != null && !ruta.isEmpty() && radioRutaKm > 0) {
                if (!estaCercaDeRuta(g.getLat(), g.getLon(), ruta, radioRutaKm)) {
                    continue; // Se aleja demasiado de la trayectoria
                }
            }

            // Si pasa todos los filtros activos, la añadimos
            resultado.add(g);
        }

        return resultado;
    }

    // --- METODOS AUXILIARES MATEMATICOS ---
    private static boolean estaCercaDeRuta(double lat, double lon, List<LatLng> puntos, double radioKm) {
        for (LatLng p : puntos) {
            if (distanciaKm(lat, lon, p.latitude, p.longitude) <= radioKm) {
                return true; // Esta cerca de al menos un punto de la polyline
            }
        }
        return false;
    }

    /**
     * Formula de Haversine para distancia entre dos coordenadas geograficas en km.
     */
    public static double distanciaKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0; // Radio de la Tierra en km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
