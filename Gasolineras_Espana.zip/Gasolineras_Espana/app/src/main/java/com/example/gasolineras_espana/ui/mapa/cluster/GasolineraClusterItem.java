package com.example.gasolineras_espana.ui.mapa.cluster;

import com.example.gasolineras_espana.model.Gasolinera;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

/*
 * Clase adaptadora que permite usar una Gasolinera dentro del ClusterManager.
 *
 * Responsabilidad:
 * Envolver un objeto Gasolinera para que la libreria de clustering pueda
 * representarlo como marcador en el mapa.
 *
 * Funcionamiento:
 * - Implementa ClusterItem, que es la interfaz que necesita ClusterManager.
 * - Convierte la latitud y longitud de la gasolinera en un objeto LatLng.
 * - Define el titulo y el texto secundario del marcador.
 * - Mantiene una referencia a la Gasolinera original para recuperar todos
 *   sus datos al hacer click.
 */

public class GasolineraClusterItem implements ClusterItem {

    private final LatLng position;
    private final String titulo;

    // Fragmento de codigo reutilizable
    private final String snippet;
    private final Gasolinera gasolinera;

    // Crea un objeto Cluster con los datos de la gasolinera
    public GasolineraClusterItem(Gasolinera gasolinera) {
        this.gasolinera = gasolinera;
        this.position = new LatLng(gasolinera.getLat(), gasolinera.getLon());

        // Si no hay rotulo, ponemos un valor generico para no dejar el marker vacio
        String rotulo = gasolinera.getRotulo();
        if (rotulo == null || rotulo.trim().isEmpty()) {
            rotulo = "Gasolinera";
        }
        this.titulo = rotulo;

        String municipioStr = gasolinera.getMunicipio() != null ? gasolinera.getMunicipio().trim() : "Desconocido";

        // El snippet aparece justo debajo del titulo en el popup del marker (fragmento de codigo reutilizable)
        this.snippet = "Municipio: " + municipioStr
                + " | P95: " + gasolinera.getP95()
                + " | Diesel: " + gasolinera.getDiesel();
    }

    @Override
    public LatLng getPosition() {
        return position;
    }

    @Override
    public String getTitle() {
        return titulo;
    }

    @Override
    public String getSnippet() {
        return snippet;
    }

    @Override
    public Float getZIndex() {
        return null;
    }

    // Necesario para recuperar los datos completos cuando el usuario hace click en el marker
    public Gasolinera getGasolinera() {
        return gasolinera;
    }
}