package com.example.gasolineras_espana.ui.mapa;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.utils.BrandUtils;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;


/*
 * Activity que muestra el detalle de una gasolinera.
 *
 * Responsabilidad:
 * Recibir los datos desde MapaActivity mediante Intent y mostrarlos en pantalla.
 *
 * Funcionamiento:
 * - Recupera los datos enviados (rotulo, direccion, precios, coordenadas).
 * - Rellena la interfaz con la informacion de la gasolinera.
 * - Muestra el logo correspondiente usando BrandUtils.
 * - Permite abrir Google Maps para navegar hasta la ubicacion.
 *
 */

public class DetalleActivity extends AppCompatActivity {

    // Etiquetas estaticas para enviarnos "paquetes" de datos a traves del Intent
    public static final String EXTRA_ROTULO = "extra_rotulo";
    public static final String EXTRA_DIRECCION = "extra_direccion";
    public static final String EXTRA_MUNICIPIO = "extra_municipio";
    public static final String EXTRA_HORARIO = "extra_horario";
    public static final String EXTRA_PRECIOS = "extra_precios";
    public static final String EXTRA_LAT = "extra_lat";
    public static final String EXTRA_LON = "extra_lon";
    public static final String EXTRA_ID = "extra_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbarDetalle);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        // Atar los hilos entre XML (vistas) y nuestro codigo Java
        ImageView imgLogo = findViewById(R.id.imgDetalleLogoToolbar);
        TextView txtRotulo = findViewById(R.id.txtDetalleRotuloToolbar);
        TextView txtDireccion = findViewById(R.id.txtDetalleDireccion);
        TextView txtHorario = findViewById(R.id.txtDetalleHorario);
        TextView txtPrecios = findViewById(R.id.txtDetallePrecios);
        Button btnIrMaps = findViewById(R.id.btnIrMaps);
        WebView wvGraficas = findViewById(R.id.wvGraficas);
        android.widget.ImageButton btnFavorito = findViewById(R.id.btnFavorito);

        // Instancias de Firebase
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Recuperamos el ID de documento guardado al hacer login.
        // Usamos SharedPreferences porque el login se hace contra Firestore manualmente,
        // sin pasar por FirebaseAuth, por lo que getCurrentUser() siempre seria null.
        String userId = getSharedPreferences("SesionUsuario", MODE_PRIVATE)
                .getString("userId", null);

        if (userId == null) {
            // Sesion no encontrada: volvemos al login
            startActivity(new Intent(this, com.example.gasolineras_espana.ui.MainActivity.class));
            finish();
            return;
        }

        // Recuperar el 'paquete' de datos que nos ha pasado MapaActivity al hacer click
        Intent intent = getIntent();
        String id = intent.getStringExtra(EXTRA_ID);
        String rotulo = intent.getStringExtra(EXTRA_ROTULO);
        String direccion = intent.getStringExtra(EXTRA_DIRECCION) + ", " + intent.getStringExtra(EXTRA_MUNICIPIO);
        String horario = intent.getStringExtra(EXTRA_HORARIO);
        String precios = intent.getStringExtra(EXTRA_PRECIOS);

        // Cuidado con coordenadas raras: 0.0 sera el seguro si algo falla al recibirlas
        double lat = intent.getDoubleExtra(EXTRA_LAT, 0.0);
        double lon = intent.getDoubleExtra(EXTRA_LON, 0.0);
        // Estado visual del favorito
        final boolean[] isFavorite = {false};

        btnFavorito.setOnClickListener(v -> {
            isFavorite[0] = !isFavorite[0];
            if (isFavorite[0]) {
                btnFavorito.setImageResource(R.drawable.ic_heart);
                btnFavorito.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.color_favorito_activo));
                db.collection("usuarios").document(userId)
                        .update("id_gasolineras", FieldValue.arrayUnion(id))
                        .addOnSuccessListener(aVoid -> {
                            btnFavorito.setImageResource(R.drawable.ic_heart);
                            btnFavorito.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.color_favorito_activo));
                            Toast.makeText(this, getString(R.string.toast_favorito_anadido), Toast.LENGTH_SHORT).show();
                        });
            } else {
                btnFavorito.setImageResource(R.drawable.ic_heart_border);
                btnFavorito.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.color_favorito_inactivo));
                db.collection("usuarios").document(userId)
                        .update("id_gasolineras", FieldValue.arrayRemove(id))
                        .addOnSuccessListener(aVoid -> {
                            btnFavorito.setImageResource(R.drawable.ic_heart_border);
                            btnFavorito.setColorFilter(androidx.core.content.ContextCompat.getColor(this, R.color.color_favorito_inactivo));
                            Toast.makeText(this, getString(R.string.toast_favorito_eliminado), Toast.LENGTH_SHORT).show();
                        });
            }
        });

        // Rellenamos el layout para que luzca bien
        txtRotulo.setText(rotulo != null ? rotulo : getString(R.string.text_detalle_rotulo_defecto));
        txtDireccion.setText(direccion);
        String horarioTexto = horario != null ? horario : getString(R.string.text_detalle_horario_sin_especificar);
        txtHorario.setText(getString(R.string.text_detalle_horario_prefijo, horarioTexto));
        txtPrecios.setText(precios);

        // Llamamos a BrandUtils para obtener el logo correspondiente
        if (rotulo != null) {
            int recursoLogo = BrandUtils.getLogoResId(rotulo);
            imgLogo.setImageResource(recursoLogo);
        }

        // "Como llegar" mediante Google Maps
        btnIrMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Preparamos un link especial (schema google.navigation) que abre el modo coche
                Uri gmmIntentUri = Uri.parse("google.navigation:q=" + lat + "," + lon);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                // Aseguramos que se intente abrir con la app oficial de Google Maps
                mapIntent.setPackage("com.google.android.apps.maps");

                // Comprobamos si el usuario tiene google maps
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                } else {
                    // Si no la tiene, un aviso y no crashea nada
                    Toast.makeText(DetalleActivity.this, getString(R.string.error_google_maps_no_instalado), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 1. Configuración del WebView (Limpia y estándar)
        WebSettings settings = wvGraficas.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // Importante para que Grafana cargue bien
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36");

        String url = "http://136.116.197.208:3000/d-solo/adwvznp/fuel4less?orgId=1&from=now-50d&to=now&var-id_gasolinera="+id+"&panelId=1&theme=dark&timezone=browser&refresh=2h";

        // 4. Carga directa (Sin logins, sin contraseñas, sin tokens)
        wvGraficas.setWebViewClient(new WebViewClient());
        wvGraficas.loadUrl(url);
    }
}
