package com.example.gasolineras_espana.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.example.gasolineras_espana.data.GasolinerasRepository;
import com.example.gasolineras_espana.model.Gasolinera;

public class Registro extends AppCompatActivity {
    FirebaseAuth mAuth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText etUsuario = findViewById(R.id.etUsuario);
        EditText etContrasenia = findViewById(R.id.etContraseniaAntigua);
        EditText etCorreo = findViewById(R.id.etCorreo);
        AutoCompleteTextView atvProvincia = findViewById(R.id.atvProvincia);
        AutoCompleteTextView atvMunicipio = findViewById(R.id.atvMunicipio);
        Spinner spnCombustible = findViewById(R.id.spnCombustible);
        Button btnRegistro = findViewById(R.id.btnRegistro);

        // Autocompletado de provincia con la lista fija de las 52 provincias de España
        String[] provincias = getResources().getStringArray(R.array.provincias_array);
        ArrayAdapter<String> adapterProvincias = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, provincias);
        atvProvincia.setAdapter(adapterProvincias);
        atvProvincia.setThreshold(1); // Muestra sugerencias desde el primer caracter

        // Autocompletado de municipios: se carga del repositorio ya en memoria y se filtra por provincia
        GasolinerasRepository repo = GasolinerasRepository.getInstance();
        repo.cargarGasolineras(this); // Si ya están cargadas, no hace nada
        repo.getGasolineras().observe(this, gasolineras -> {
            // Cuando el usuario elige una provincia, actualizamos los municipios del desplegable
            atvProvincia.setOnItemClickListener((parent, view, position, id) -> {
                String provinciaElegida = atvProvincia.getText().toString().trim();
                atvMunicipio.setText(""); // Limpiamos el municipio anterior
                actualizarMunicipios(gasolineras, provinciaElegida, atvMunicipio);
            });

            // También lo aplicamos si la provincia ya tenía valor al entrar a la pantalla
            String provinciaActual = atvProvincia.getText().toString().trim();
            if (!provinciaActual.isEmpty()) {
                actualizarMunicipios(gasolineras, provinciaActual, atvMunicipio);
            }
        });

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnRegistro.setOnClickListener(v -> {
            String usuario = etUsuario.getText().toString().trim();
            String contrasenia = etContrasenia.getText().toString().trim();
            String correo = etCorreo.getText().toString().trim();
            String provincia = atvProvincia.getText().toString().trim();
            String municipio = atvMunicipio.getText().toString().trim();

            if (TextUtils.isEmpty(usuario) || TextUtils.isEmpty(contrasenia) ||
                    TextUtils.isEmpty(correo) || TextUtils.isEmpty(provincia) ||
                    TextUtils.isEmpty(municipio)) {
                Toast.makeText(Registro.this, "Faltan campos por rellenar", Toast.LENGTH_SHORT).show();
            } else {
                // --- NUEVA LÓGICA: Comprobar si el nombre de usuario ya existe ---
                db.collection("usuarios")
                        .whereEqualTo("usuario", usuario)
                        .get()
                        .addOnCompleteListener(taskUsuario -> {
                            if (taskUsuario.isSuccessful()) {
                                if (!taskUsuario.getResult().isEmpty()) {
                                    // Si la lista de resultados no está vacía, el usuario ya existe
                                    Toast.makeText(Registro.this, "El nombre de usuario ya existe", Toast.LENGTH_SHORT).show();
                                } else {
                                    // El nombre de usuario está libre, procedemos a crear la cuenta
                                    crearCuentaAuth(correo, contrasenia, usuario, provincia, municipio, spnCombustible);
                                }
                            } else {
                                Toast.makeText(Registro.this, "Error al comprobar usuario", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    // He creado este método aparte para que el código sea más limpio y no haya tantas llaves anidadas
    private void crearCuentaAuth(String correo, String contrasenia, String usuario, String provincia, String municipio, Spinner spnCombustible) {
        mAuth.createUserWithEmailAndPassword(correo, contrasenia)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String userId = mAuth.getCurrentUser().getUid();

                        Map<String, Object> userProfile = new HashMap<>();
                        userProfile.put("usuario", usuario);
                        userProfile.put("correo", correo);
                        userProfile.put("contrasenia", contrasenia);
                        userProfile.put("provincia", provincia);
                        userProfile.put("municipio", municipio);
                        userProfile.put("combustible_fav", spnCombustible.getSelectedItem().toString());
                        userProfile.put("id_gasolineras", new java.util.ArrayList<String>());

                        db.collection("usuarios").document(userId)
                                .set(userProfile)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(Registro.this, "¡Registro completado con éxito!", Toast.LENGTH_LONG).show();
                                    finish();
                                });
                    } else {
                        // --- GESTIÓN DE EXCEPCIONES PERSONALIZADA ---
                        String mensajeError = "Error al registrarse"; // Mensaje por defecto

                        try {
                            throw task.getException();
                        } catch (FirebaseAuthWeakPasswordException e) {
                            mensajeError = "La contraseña es muy corta (mínimo 6 caracteres)";
                        } catch (FirebaseAuthInvalidCredentialsException e) {
                            mensajeError = "El formato del correo electrónico no es válido";
                        } catch (FirebaseAuthUserCollisionException e) {
                            mensajeError = "Este correo ya está registrado en otra cuenta";
                        } catch (Exception e) {
                            mensajeError = "Error desconocido: " + e.getMessage();
                        }

                        Toast.makeText(Registro.this, mensajeError, Toast.LENGTH_LONG).show();
                    }
                });
    }
    /*
     * Filtra los municipios de la lista de gasolineras por la provincia indicada
     * y los asigna como autocompletado al campo atvMunicipio.
     * Usa TreeSet para devolver los municipios ordenados alfabeticamente sin duplicados.
     */
    private void actualizarMunicipios(List<Gasolinera> gasolineras,
                                      String provincia,
                                      AutoCompleteTextView atvMunicipio) {
        if (gasolineras == null || provincia.isEmpty()) return;

        TreeSet<String> municipiosSet = new TreeSet<>();
        for (Gasolinera g : gasolineras) {
            if (g.getProvincia() != null
                    && g.getProvincia().equalsIgnoreCase(provincia)
                    && g.getMunicipio() != null
                    && !g.getMunicipio().trim().isEmpty()) {
                municipiosSet.add(g.getMunicipio().trim());
            }
        }

        ArrayAdapter<String> adapterMunicipios = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, new ArrayList<>(municipiosSet));
        atvMunicipio.setAdapter(adapterMunicipios);
        atvMunicipio.setThreshold(1);
    }
}