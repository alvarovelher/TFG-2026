package com.example.gasolineras_espana.ui.mapa.rutas;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/*
 * Clase de utilidad para comunicarse con Google Routes API v2.
 *
 * Responsabilidad:
 * Calcular una ruta entre dos puntos geograficos y devolver la polyline
 * codificada que representa el recorrido.
 *
 * Funcionamiento:
 * - Construye una peticion POST con origen, destino y modo de viaje DRIVE.
 * - Envia la peticion al endpoint computeRoutes de Google.
 * - Usa cabeceras obligatorias como API Key y FieldMask.
 * - Lee la respuesta JSON y extrae routes[0].polyline.encodedPolyline.
 *
 * Nota: la decodificacion y el dibujo en el mapa se realizan desde RutaActivity.
 */
public class RoutesApi {

    private static final String TAG = "RoutesApi";
    private static final String ENDPOINT = "https://routes.googleapis.com/directions/v2:computeRoutes";

    // Campo solicitado a la API: solo la polyline codificada, para minimizar la respuesta.
    private static final String FIELD_MASK = "routes.polyline.encodedPolyline";

    /*
     * Llama a Google Routes API y devuelve la polyline codificada de la ruta.
     * Devuelve null si la llamada HTTP falla o la API no devuelve ruta.
     */
    public static String computeRoute(double originLat, double originLon,
                                      double destLat, double destLon,
                                      String apiKey) {
        HttpURLConnection connection = null;
        try {
            // --- 1. Construir el cuerpo JSON de la peticion ---
            // La API espera coordenadas como objetos "location" con "latLng".
            JSONObject originLatLng = new JSONObject();
            originLatLng.put("latitude", originLat);
            originLatLng.put("longitude", originLon);

            JSONObject destinationLatLng = new JSONObject();
            destinationLatLng.put("latitude", destLat);
            destinationLatLng.put("longitude", destLon);

            JSONObject origin = new JSONObject();
            origin.put("location", new JSONObject().put("latLng", originLatLng));

            JSONObject destination = new JSONObject();
            destination.put("location", new JSONObject().put("latLng", destinationLatLng));

            JSONObject body = new JSONObject();
            body.put("origin", origin);
            body.put("destination", destination);
            body.put("travelMode", "DRIVE");

            // --- 2. Abrir la conexion HTTP ---
            URL url = new URL(ENDPOINT);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000); // 10 segundos para conectar
            connection.setReadTimeout(15000);    // 15 segundos para leer respuesta
            connection.setDoOutput(true);        // Indicamos que vamos a enviar un body

            // --- 3. Establecer las cabeceras requeridas por la API ---
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("X-Goog-Api-Key", apiKey);
            connection.setRequestProperty("X-Goog-FieldMask", FIELD_MASK);

            // --- 4. Escribir el body JSON en el stream de salida ---
            byte[] bodyBytes = body.toString().getBytes(StandardCharsets.UTF_8);
            OutputStream os = connection.getOutputStream();
            os.write(bodyBytes);
            os.flush();
            os.close();

            // --- 5. Leer la respuesta ---
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                // Leemos el stream de error para ver que reporta la API
                BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder errorBody = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorBody.append(line);
                }
                Log.e(TAG, "Error HTTP " + responseCode + ": " + errorBody);
                return null;
            }

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder responseBody = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                responseBody.append(line);
            }
            reader.close();

            // --- 6. Parsear la respuesta JSON y extraer la polyline ---
            // Estructura esperada: { "routes": [ { "polyline": { "encodedPolyline": "..." } } ] }
            JSONObject jsonResponse = new JSONObject(responseBody.toString());
            JSONArray routes = jsonResponse.getJSONArray("routes");

            if (routes.length() == 0) {
                Log.e(TAG, "La API no devolvio ninguna ruta.");
                return null;
            }

            String encodedPolyline = routes
                    .getJSONObject(0)
                    .getJSONObject("polyline")
                    .getString("encodedPolyline");

            return encodedPolyline;

        } catch (Exception e) {
            Log.e(TAG, "Excepcion al llamar a Routes API: " + e.getMessage(), e);
            return null;
        } finally {
            // cerramos la conexion
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
