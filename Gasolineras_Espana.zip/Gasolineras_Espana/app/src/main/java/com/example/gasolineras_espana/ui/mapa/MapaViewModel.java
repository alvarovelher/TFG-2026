package com.example.gasolineras_espana.ui.mapa;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.gasolineras_espana.geojson.GeoJsonDownloader;
import com.example.gasolineras_espana.model.GeoJsonData;
import com.example.gasolineras_espana.model.Gasolinera;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Este ViewModel maneja el hilo de red y guarda nuestra lista.
// Asi si el usuario gira el movil, no perdemos toda la info cargada ni hay cierres inesperados.
public class MapaViewModel extends ViewModel {

    private static final String URL_GEOJSON = "https://raw.githubusercontent.com/MigMoy93/gasolineras-espana/main/gasolineras.geojson";
    
    // LiveData nos permite observar el cambio de estados desde la Actividad
    private final MutableLiveData<List<Gasolinera>> gasolinerasLiveData = new MutableLiveData<>();
    private final MutableLiveData<Boolean> cargandoLiveData = new MutableLiveData<>(false);

    // Gestor de hilos (Ejecuta tareas en segundo plano)
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public LiveData<List<Gasolinera>> getGasolineras() {
        return gasolinerasLiveData;
    }

    public LiveData<Boolean> getCargando() {
        return cargandoLiveData;
    }

    public void cargarGasolineras() {
        // Evitamos volver a descargar si ya las tenemos (ej: al girar la pantalla)
        if (gasolinerasLiveData.getValue() != null && !gasolinerasLiveData.getValue().isEmpty()) {
            return; 
        }

        cargandoLiveData.setValue(true);

        // Lanzamos al hilo
        executorService.execute(() -> {
            try {
                GeoJsonDownloader downloader = new GeoJsonDownloader();
                GeoJsonData data = downloader.descargarYParsear(URL_GEOJSON);
                
                // Usamos postValue porque estamos fuera del hilo principao (UI)
                gasolinerasLiveData.postValue(data.getGasolineras());
            } catch (Exception e) {
                Log.e("MAPA_VM", "Error descargando geojson", e);
            } finally {
                cargandoLiveData.postValue(false);
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        // Aseguramos matar al trabajador si destruyen esta app de memoria
        executorService.shutdown();
    }
}
