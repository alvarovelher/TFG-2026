package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // 1. Enlazamos los campos de texto y el botón
        android.widget.EditText etUsuario = findViewById(R.id.etUsuario);
        android.widget.EditText etContrasenia = findViewById(R.id.etContrasenia);
        android.widget.Button btnLogin = findViewById(R.id.btnRegistrarse);

        // 2. Configuración del evento click para el inicio de sesión
        btnLogin.setOnClickListener(v -> {
            String usuarioInput = etUsuario.getText().toString().trim();
            String passInput = etContrasenia.getText().toString().trim();

            if (usuarioInput.isEmpty() || passInput.isEmpty()) {
                Toast.makeText(this, "Por favor, rellena todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Consultamos Firestore para verificar las credenciales
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios")
                    .whereEqualTo("usuario", usuarioInput)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            // El usuario existe, comprobamos la contraseña
                            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                                String dbPass = doc.getString("contrasenia");
                                if (dbPass != null && dbPass.equals(passInput)) {
                                    // Login correcto
                                    Log.d("FirestoreLogin", "Login exitoso para: " + usuarioInput);
                                    Intent intent = new Intent(MainActivity.this, MapaActivity.class);
                                    startActivity(intent);
                                    finish();
                                    return;
                                }
                            }
                            // Si salimos del bucle sin retornar, la pass está mal
                            Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                        } else {
                            // El usuario no existe en la colección
                            Toast.makeText(this, "El usuario no existe", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("FirestoreLogin", "Error al conectar", e);
                        Toast.makeText(this, "Error de conexión con el servidor", Toast.LENGTH_SHORT).show();
                    });
        });
    }


}