package com.example.gasolineras_espana.data;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.gasolineras_espana.geojson.GeoJsonDownloader;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.model.GeoJsonData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*
 * Repositorio principal de gasolineras.
 *
 * Responsabilidad:
 * Centralizar el acceso a los datos de gasolineras usando el patron Singleton.
 * Evita descargas duplicadas y mantiene los datos en memoria durante la sesion.
 *
 * Funcionamiento:
 * - Expone los datos mediante LiveData para que la interfaz pueda observarlos.
 * - Usa un ExecutorService de un unico hilo para no bloquear la pantalla.
 * - Si ya hay datos cargados, no vuelve a descargarlos.
 * - Primero intenta cargar el fichero local gasolineras_local.geojson.
 * - Si no existe fichero local, descarga el GeoJSON desde GitHub.
 *
 * Variables principales:
 * - gasolinerasLiveData: lista observable de gasolineras.
 * - cargandoLiveData: indica si se esta realizando una carga.
 * - executorService: hilo secundario para operaciones de red o fichero.
 *
 * Dependencias: GeoJsonDownloader, GeoJsonParser, GeoJsonData
 * Usada por: MapaViewModel
 */
public class GasolinerasRepository {

    private static GasolinerasRepository instance;
    private static final String URL_GEOJSON = "https://raw.githubusercontent.com/MigMoy93/gasolineras-espana/main/gasolineras.geojson";

    // MutableLiveDAta permite lectura y escritura de datos, setValue() / postValue()
    private final MutableLiveData<List<Gasolinera>> gasolinerasLiveData = new MutableLiveData<>();
    private final MutableLiveData<Boolean> cargandoLiveData = new MutableLiveData<>(false);

    // Ejecuta tareas en segundo plano para no bloquear la interfaz (En otro hilo)
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    private GasolinerasRepository() {}

    public static synchronized GasolinerasRepository getInstance() {
        if (instance == null) {
            instance = new GasolinerasRepository();
        }
        return instance;
    }

    public LiveData<List<Gasolinera>> getGasolineras() {
        return gasolinerasLiveData;
    }

    // Devuelve el estado de carga para mostrar u ocultar indicadores en la interfaz.
    public LiveData<Boolean> getCargando() {
        return cargandoLiveData;
    }

    // Se actualiza el Metodo que descarga y procesa el GeoJSON para priorizar datos locales frescos
    public void cargarGasolineras(android.content.Context context) {
        if (gasolinerasLiveData.getValue() != null && !gasolinerasLiveData.getValue().isEmpty()) {
            return; // Ya estan cargadas
        }

        cargarDesdeLocalOInternet(context);
    }

    public void cargarDesdeLocalOInternet(android.content.Context context) {
        cargarDesdeLocalOInternet(context, false);
    }

    // Carga datos desde fichero local si existe y es del ciclo actual (posterior a la ultima hora de corte).
    // La cache se invalida a las 09:00 AM cada dia, coincidiendo con la publicacion de precios del Ministerio.
    // Si force es true, o no hay fichero local, descarga el GeoJSON desde internet.
    public void cargarDesdeLocalOInternet(android.content.Context context, boolean force) {
        cargandoLiveData.postValue(true);
        executorService.execute(() -> {
            try {
                GeoJsonData data = null;
                java.io.File localFile = new java.io.File(context.getFilesDir(), "gasolineras_local.geojson");

                // Determinar si los datos locales estan obsoletos usando una hora de corte fija (09:00 AM).
                // El archivo se considera valido si se descargo DESPUES del ultimo corte de las 09:00 AM.
                // Esto garantiza que la primera apertura del dia despues de las 09:00 siempre usa datos frescos.
                boolean needsDownload = force; // Si es forzado, ya sabemos que toca bajar

                if (!needsDownload && localFile.exists()) {
                    long lastModified = localFile.lastModified();
                    long now = System.currentTimeMillis();

                    // Calcular el timestamp del ultimo corte de las 09:00 AM
                    java.util.Calendar ultimoCorte = java.util.Calendar.getInstance();
                    ultimoCorte.set(java.util.Calendar.HOUR_OF_DAY, 9);
                    ultimoCorte.set(java.util.Calendar.MINUTE, 0);
                    ultimoCorte.set(java.util.Calendar.SECOND, 0);
                    ultimoCorte.set(java.util.Calendar.MILLISECOND, 0);

                    // Si aun no han llegado las 09:00 de hoy, el ultimo corte valido fue ayer a las 09:00
                    if (now < ultimoCorte.getTimeInMillis()) {
                        ultimoCorte.add(java.util.Calendar.DAY_OF_YEAR, -1);
                    }

                    // Si el archivo es anterior al ultimo corte, los datos estan obsoletos
                    needsDownload = (lastModified < ultimoCorte.getTimeInMillis());
                    Log.d("REPO", "Ultimo corte: " + ultimoCorte.getTime() + " | Descarga necesaria: " + needsDownload);

                } else if (!localFile.exists()) {
                    needsDownload = true;
                }

                if (needsDownload) {
                    Log.d("REPO", "Descargando nuevo archivo de internet... (Forzado: " + force + ")");
                    java.net.URL url = new java.net.URL(URL_GEOJSON);
                    java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.connect();
                    
                    if (connection.getResponseCode() == java.net.HttpURLConnection.HTTP_OK) {
                        java.io.InputStream is = connection.getInputStream();
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(localFile);
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = is.read(buffer)) != -1) {
                            fos.write(buffer, 0, bytesRead);
                        }
                        fos.close();
                        is.close();
                        Log.d("REPO", "Archivo descargado y guardado con éxito.");
                    }
                    connection.disconnect();
                }

                if (localFile.exists()) {
                    // Cargar desde almacenamiento local
                    java.io.InputStream is = new java.io.FileInputStream(localFile);
                    com.example.gasolineras_espana.geojson.GeoJsonParser parser = new com.example.gasolineras_espana.geojson.GeoJsonParser();
                    data = parser.parsearStream(is);
                    is.close();
                    Log.d("REPO", "Gasolineras parseadas desde fichero local");
                }

                if (data != null && data.getGasolineras() != null) {
                    gasolinerasLiveData.postValue(data.getGasolineras());
                }
            } catch (Exception e) {
                Log.e("REPO", "Error obteniendo geojson", e);
            } finally {
                cargandoLiveData.postValue(false);
            }
        });
    }
}
