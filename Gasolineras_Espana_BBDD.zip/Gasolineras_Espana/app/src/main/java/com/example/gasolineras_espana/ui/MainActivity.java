package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Corrección 1: Declaración de variable en Java
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("usuarios")
                .get()
                // Corrección 2: Sintaxis de OnSuccessListener en Java (lambda)
                .addOnSuccessListener(querySnapshot -> {
                    for (QueryDocumentSnapshot document : querySnapshot) { // querySnapshot es el resultado, document es cada documento individual
                        // Corrección 3: Concatenación de Strings en Java
                        Log.d("Firestore", document.getId() + " => " + document.getData());
                        // Corrección 1 y 3: Declaración de String y concatenación
                        String nombreUsuario = document.getString("usuario");
                        String email = document.getString("correo");
                        Log.d("Firestore", "Usuario: " + nombreUsuario + ", Email: " + email);
                    }
                })
                // Corrección 2: Sintaxis de OnFailureListener en Java (lambda)
                .addOnFailureListener(e -> {
                    Log.w("Firestore", "Error al obtener documentos: ", e);
                });

        //startActivity(new Intent(this, MapaActivity.class));
        //finish();
    }


}