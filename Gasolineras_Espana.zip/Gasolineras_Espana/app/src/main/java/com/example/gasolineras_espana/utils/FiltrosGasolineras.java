package com.example.gasolineras_espana.utils;

import com.example.gasolineras_espana.model.Gasolinera;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

/*
 * Clase utilitaria para filtrar gasolineras segun distintos criterios.
 *
 * Responsabilidad:
 * Aplicar filtros sobre la lista completa de gasolineras y devolver solo
 * las que cumplen las condiciones indicadas.
 *
 * Funcionamiento:
 * - Filtra por compania o rotulo.
 * - Filtra por distancia minima desde el origen.
 * - Filtra por cercania a una ruta calculada.
 * - Usa la formula de Haversine para calcular distancias entre coordenadas.
 */

public class FiltrosGasolineras {

    /*
     * Aplica multiples filtros a una lista de gasolineras en una sola pasada.
     * Permite reutilizacion de codigo tanto en MapaActivity como en RutaActivity.
     */
    public static List<Gasolinera> aplicarFiltros(
            List<Gasolinera> todas,
            String compania,
            LatLng origen,
            double minKmDesdeOrigen,
            List<LatLng> ruta,
            double radioRutaKm,
            boolean soloAbierto24h) {

        List<Gasolinera> resultado = new ArrayList<>();

        if (todas == null || todas.isEmpty()) return resultado;

        // --- OPTIMIZACION: Pre-calcular bounding box y polyline reducida una sola vez ---
        // Evita recalcular para cada una de las ~11.000 gasolineras.
        double[] bbox = null;
        List<LatLng> puntosEficientes = ruta;
        if (ruta != null && !ruta.isEmpty() && radioRutaKm > 0) {
            bbox = calcularBoundingBox(ruta, radioRutaKm);
            puntosEficientes = submuestrear(ruta);
        }

        for (Gasolinera g : todas) {
            // Descartamos las que no tienen coordenadas
            if (g.getLat() == 0.0 && g.getLon() == 0.0) continue;

            // 1. Filtro de Compañia
            if (compania != null && !compania.trim().isEmpty()) {
                if (g.getRotulo() == null || !g.getRotulo().toUpperCase().contains(compania.toUpperCase())) {
                    continue; // No coincide con la marca del filtro
                }
            }

            // 2. Filtro Abierto 24h
            if (soloAbierto24h) {
                String horario = g.getHorario();
                if (horario == null || !horario.toUpperCase().contains("24H")) {
                    continue; // No tiene horario 24 horas
                }
            }

            // 3. Filtro de Autonomia (Distancia minima desde Origen en linea recta)
            if (origen != null && minKmDesdeOrigen > 0) {
                double distanciaDesdeInicio = distanciaKm(origen.latitude, origen.longitude, g.getLat(), g.getLon());
                if (distanciaDesdeInicio < minKmDesdeOrigen) {
                    continue; // Esta muy cerca del origen, la saltamos
                }
            }

            // 4. Filtro de Ruta (Radio de desvio maximo)
            if (puntosEficientes != null && !puntosEficientes.isEmpty() && radioRutaKm > 0) {
                // PRE-FILTRO: descarte rapido por bounding box (sin trigonometria)
                if (!dentroDelBoundingBox(g.getLat(), g.getLon(), bbox)) {
                    continue; // Fuera de la caja que envuelve la ruta → imposible estar cerca
                }
                // FILTRO PRECISO: Haversine solo sobre los puntos que pasaron el bbox
                if (!estaCercaDeRuta(g.getLat(), g.getLon(), puntosEficientes, radioRutaKm)) {
                    continue; // Se aleja demasiado de la trayectoria
                }
            }

            // Si pasa todos los filtros activos, la añadimos
            resultado.add(g);
        }

        return resultado;
    }

    // --- METODOS AUXILIARES MATEMATICOS ---

    /*
     * Calcula el bounding box (caja envolvente) de la polyline ampliado con el radio.
     * Resultado: [minLat, maxLat, minLon, maxLon].
     * Conversion aproximada: 1 grado ≈ 111 km (suficiente para un pre-filtro).
     */
    private static double[] calcularBoundingBox(List<LatLng> puntos, double radioKm) {
        double minLat = Double.MAX_VALUE,  maxLat = -Double.MAX_VALUE;
        double minLon = Double.MAX_VALUE,  maxLon = -Double.MAX_VALUE;
        for (LatLng p : puntos) {
            if (p.latitude  < minLat) minLat = p.latitude;
            if (p.latitude  > maxLat) maxLat = p.latitude;
            if (p.longitude < minLon) minLon = p.longitude;
            if (p.longitude > maxLon) maxLon = p.longitude;
        }
        double margenLat = radioKm / 111.0;
        // Para la longitud usamos la latitud central (coseno): margen conservador
        double centerLat = (minLat + maxLat) / 2.0;
        double margenLon = radioKm / (111.0 * Math.cos(Math.toRadians(centerLat)));
        return new double[]{minLat - margenLat, maxLat + margenLat,
                minLon - margenLon, maxLon + margenLon};
    }

    // Comprobacion barata (sin trigonometria): devuelve true si el punto esta dentro del bounding box.
    private static boolean dentroDelBoundingBox(double lat, double lon, double[] bbox) {
        return lat >= bbox[0] && lat <= bbox[1] && lon >= bbox[2] && lon <= bbox[3];
    }

    /*
     * Reduce la polyline a un maximo de 150 puntos para minimizar el numero de
     * llamadas Haversine. Con un radio de 5 km, el error maximo introducido es
     * inferior a la propia tolerancia del filtro.
     */
    private static List<LatLng> submuestrear(List<LatLng> puntos) {
        final int MAX_PUNTOS = 150;
        int step = Math.max(1, puntos.size() / MAX_PUNTOS);
        if (step == 1) return puntos; // Ya es suficientemente corta, sin cambios
        List<LatLng> reducidos = new ArrayList<>(MAX_PUNTOS + 1);
        for (int i = 0; i < puntos.size(); i += step) {
            reducidos.add(puntos.get(i));
        }
        // Aseguramos que el ultimo punto de la ruta siempre esta incluido
        LatLng ultimo = puntos.get(puntos.size() - 1);
        if (!reducidos.get(reducidos.size() - 1).equals(ultimo)) {
            reducidos.add(ultimo);
        }
        return reducidos;
    }

    /*
     * Comprueba si un punto esta a menos de radioKm de algun punto de la polyline.
     * Solo se llama sobre los puntos que ya pasaron el pre-filtro de bounding box.
     */
    private static boolean estaCercaDeRuta(double lat, double lon, List<LatLng> puntos, double radioKm) {
        for (LatLng p : puntos) {
            if (distanciaKm(lat, lon, p.latitude, p.longitude) <= radioKm) {
                return true; // Esta cerca de al menos un punto de la polyline
            }
        }
        return false;
    }

    // Formula de Haversine para distancia entre dos coordenadas geograficas en km.
    public static double distanciaKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0; // Radio de la Tierra en km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
