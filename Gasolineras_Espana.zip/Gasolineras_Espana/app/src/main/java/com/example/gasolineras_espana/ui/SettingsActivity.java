package com.example.gasolineras_espana.ui;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import com.example.gasolineras_espana.R;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.example.gasolineras_espana.data.GasolinerasRepository;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/*
 * Activity de configuracion de la aplicacion.
 *
 * Responsabilidad:
 * Gestionar las preferencias del usuario, permisos del sistema y opciones
 * de visualizacion del mapa.
 *
 * Funcionamiento:
 * - Permite activar/desactivar notificaciones y configurar su comportamiento.
 * - Gestiona permisos de ubicacion y notificaciones.
 * - Cambiar el tipo de mapa y mostrar precios en los marcadores.
 * - Muestra informacion sobre la ultima actualizacion de datos.
 * - Ofrece herramientas de mantenimiento como borrar cache local.
 *
 * Persistencia:
 * - Usa SharedPreferences ("OpcionesGasolineras") para almacenar configuraciones.
 *
 */


public class SettingsActivity extends AppCompatActivity {

    private TextView tvEstadoUbicacion, tvEstadoNotificaciones, tvUltimaActualizacion;
    private SwitchMaterial switchNotificaciones, switchMostrarPrecios;
    private CheckBox checkNotifBajadas, checkNotifActualizacion;
    private Spinner spinnerTipoMapa;

    private SharedPreferences prefs;

    private final ActivityResultLauncher<String> requestLocationLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), isGranted -> checkPermissions()
    );

    private final ActivityResultLauncher<String> requestNotificationLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), isGranted -> checkPermissions()
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbarSettings);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        prefs = getSharedPreferences("OpcionesGasolineras", Context.MODE_PRIVATE);

        iniciarVistas();
        listeners();
        cargarPreferencias();
        actualizarInfoDatos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    private void iniciarVistas() {
        tvEstadoUbicacion = findViewById(R.id.tvEstadoUbicacion);
        tvEstadoNotificaciones = findViewById(R.id.tvEstadoNotificaciones);
        tvUltimaActualizacion = findViewById(R.id.tvUltimaActualizacion);

        switchNotificaciones = findViewById(R.id.switchNotificaciones);
        checkNotifBajadas = findViewById(R.id.checkNotifBajadas);
        checkNotifActualizacion = findViewById(R.id.checkNotifActualizacion);

        switchMostrarPrecios = findViewById(R.id.switchMostrarPrecios);
        spinnerTipoMapa = findViewById(R.id.spinnerTipoMapa);

        String[] tiposMapa = {"Normal", "Satélite", "Híbrido"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tiposMapa);
        spinnerTipoMapa.setAdapter(adapter);
    }

    private void listeners() {
        findViewById(R.id.layoutPermisoUbicacion).setOnClickListener(v -> solicitarPermisoUbicacion());
        findViewById(R.id.layoutPermisoNotificaciones).setOnClickListener(v -> solicitarPermisoNotificaciones());

        switchNotificaciones.setOnCheckedChangeListener((buttonView, isChecked) -> {
            checkNotifBajadas.setEnabled(isChecked);
            checkNotifActualizacion.setEnabled(isChecked);
            guardarPreferencias();
        });

        checkNotifBajadas.setOnCheckedChangeListener((buttonView, isChecked) -> guardarPreferencias());
        checkNotifActualizacion.setOnCheckedChangeListener((buttonView, isChecked) -> guardarPreferencias());

        switchMostrarPrecios.setOnCheckedChangeListener((buttonView, isChecked) -> guardarPreferencias());

        spinnerTipoMapa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                guardarPreferencias();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        findViewById(R.id.btnActualizarAhora).setOnClickListener(v -> forzarActualizacion());
        findViewById(R.id.btnBorrarCache).setOnClickListener(v -> borrarCacheLocal());
    }

    private void cargarPreferencias() {
        boolean notifGlobal = prefs.getBoolean("pref_notificaciones", true);
        switchNotificaciones.setChecked(notifGlobal);
        checkNotifBajadas.setEnabled(notifGlobal);
        checkNotifActualizacion.setEnabled(notifGlobal);

        checkNotifBajadas.setChecked(prefs.getBoolean("pref_notif_bajadas", true));
        checkNotifActualizacion.setChecked(prefs.getBoolean("pref_notif_actualizacion", true));

        switchMostrarPrecios.setChecked(prefs.getBoolean("pref_mapa_precios", true));
        spinnerTipoMapa.setSelection(prefs.getInt("pref_mapa_tipo", 0));
    }

    private void guardarPreferencias() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("pref_notificaciones", switchNotificaciones.isChecked());
        editor.putBoolean("pref_notif_bajadas", checkNotifBajadas.isChecked());
        editor.putBoolean("pref_notif_actualizacion", checkNotifActualizacion.isChecked());
        
        editor.putBoolean("pref_mapa_precios", switchMostrarPrecios.isChecked());
        editor.putInt("pref_mapa_tipo", spinnerTipoMapa.getSelectedItemPosition());
        editor.apply();
        
        // Si hay modificaciones , avisamos al mapa que debe refrescar
        prefs.edit().putBoolean("mapa_necesita_refresco", true).apply();
    }

    private void checkPermissions() {
        // Ubicación
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            tvEstadoUbicacion.setText("Concedido");
            tvEstadoUbicacion.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            tvEstadoUbicacion.setText("Denegado");
            tvEstadoUbicacion.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        }

        // Notificaciones (Solo Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                tvEstadoNotificaciones.setText("Concedido");
                tvEstadoNotificaciones.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
            } else {
                tvEstadoNotificaciones.setText("Denegado");
                tvEstadoNotificaciones.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
            }
        } else {
            tvEstadoNotificaciones.setText("No Aplica");
            tvEstadoNotificaciones.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        }
    }

    private void solicitarPermisoUbicacion() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                abrirAjustesApp();
            } else {
                requestLocationLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        } else {
            Toast.makeText(this, "El permiso de ubicación ya está concedido", Toast.LENGTH_SHORT).show();
        }
    }

    private void solicitarPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    abrirAjustesApp();
                } else {
                    requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                }
            } else {
                Toast.makeText(this, "El permiso de notificaciones ya está concedido", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void abrirAjustesApp() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    private void actualizarInfoDatos() {
        File f = new File(getFilesDir(), "gasolineras_local.geojson");
        if (f.exists()) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
            String fecha = dateFormat.format(new Date(f.lastModified()));
            tvUltimaActualizacion.setText("Última actualización: " + fecha);
        } else {
            tvUltimaActualizacion.setText(getString(R.string.settings_datos_ultima_act, getString(R.string.settings_datos_nunca)));
        }
    }

    private void forzarActualizacion() {
        Button btn = findViewById(R.id.btnActualizarAhora);
        btn.setEnabled(false);
        btn.setText("Actualizando...");

        GasolinerasRepository repo = GasolinerasRepository.getInstance();
        
        // Observamos el estado de carga para saber cuando termina
        repo.getCargando().observe(this, cargando -> {
            if (!cargando && !btn.isEnabled()) {
                btn.setEnabled(true);
                btn.setText("ACTUALIZAR AHORA");
                actualizarInfoDatos();
                Toast.makeText(this, "Datos actualizados con éxito", Toast.LENGTH_SHORT).show();
            }
        });

        repo.cargarDesdeLocalOInternet(this, true);
    }

    private void borrarCacheLocal() {
        File f = new File(getFilesDir(), "gasolineras_local.geojson");
        if (f.exists() && f.delete()) {
            actualizarInfoDatos();
            Toast.makeText(this, "Caché borrada correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No hay caché que borrar", Toast.LENGTH_SHORT).show();
        }
    }
}
