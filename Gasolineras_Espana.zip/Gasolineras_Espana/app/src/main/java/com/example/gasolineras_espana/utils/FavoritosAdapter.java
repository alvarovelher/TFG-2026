package com.example.gasolineras_espana.utils;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.utils.BrandUtils;

import java.util.List;

public class FavoritosAdapter extends RecyclerView.Adapter<FavoritosAdapter.ViewHolder> {

    private List<Gasolinera> listaFavoritos;
    private OnItemClickListener listener;

    // Interfaz para manejar el click desde la Activity
    public interface OnItemClickListener {
        void onItemClick(Gasolinera gasolinera);
    }

    public FavoritosAdapter(List<Gasolinera> listaFavoritos, OnItemClickListener listener) {
        this.listaFavoritos = listaFavoritos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos tu CardView personalizado
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.estilo_favoritos, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Gasolinera gasolinera = listaFavoritos.get(position);

        // Rellenamos los datos con tu diseño
        holder.tvNombre.setText(gasolinera.getRotulo());
        holder.tvHorario.setText(gasolinera.getHorario());

        // Usamos tu utilidad de logos para poner la imagen correcta
        int logoResId = BrandUtils.getLogoResId(gasolinera.getRotulo());
        holder.ivLogo.setImageResource(logoResId);

        // Configuramos el click
        holder.itemView.setOnClickListener(v -> listener.onItemClick(gasolinera));
    }

    @Override
    public int getItemCount() {
        return listaFavoritos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivLogo;
        TextView tvNombre, tvHorario;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivLogo = itemView.findViewById(R.id.ivLogo);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvHorario = itemView.findViewById(R.id.tvHorario);
        }
    }
}