package com.example.gasolineras_espana.ui.mapa;

import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

// Convierte un texto (ciudad, direccion...) en coordenadas LatLng usando la API de Geocoding de Google.
// Mismo estilo que RoutesApi: metodo estatico, HttpURLConnection, sin librerias extra.
public class GeocodingApi {

    private static final String TAG = "GeocodingApi";
    private static final String ENDPOINT = "https://maps.googleapis.com/maps/api/geocode/json";

    /**
     * Convierte una direccion de texto en coordenadas geograficas.
     * Devuelve null si no se encuentra nada o falla la llamada.
     *
     * @param direccion Texto a buscar, p.ej. "Valladolid" o "Calle Mayor 5, Madrid"
     * @param apiKey    Clave de API con Geocoding habilitado
     */
    public static LatLng geocodificar(String direccion, String apiKey) {
        HttpURLConnection connection = null;
        try {
            // Codificamos el texto para que pueda ir en la URL sin caracteres raros
            String textoCodificado = URLEncoder.encode(direccion, "UTF-8");

            // region=es para que priorice resultados en España
            URL url = new URL(ENDPOINT + "?address=" + textoCodificado + "&region=es&key=" + apiKey);

            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "Error HTTP " + responseCode + " buscando: " + direccion);
                return null;
            }

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder respuesta = new StringBuilder();
            String linea;
            while ((linea = reader.readLine()) != null) {
                respuesta.append(linea);
            }
            reader.close();

            // Estructura esperada:
            // { "status": "OK", "results": [ { "geometry": { "location": { "lat": X, "lng": Y } } } ] }
            JSONObject json = new JSONObject(respuesta.toString());
            String status = json.getString("status");

            if (!status.equals("OK")) {
                Log.e(TAG, "Geocoding status: " + status + " para: " + direccion);
                return null;
            }

            JSONArray results = json.getJSONArray("results");
            if (results.length() == 0) {
                Log.e(TAG, "Sin resultados para: " + direccion);
                return null;
            }

            // Cogemos el primer resultado que suele ser el mas relevante
            JSONObject location = results
                    .getJSONObject(0)
                    .getJSONObject("geometry")
                    .getJSONObject("location");

            double lat = location.getDouble("lat");
            double lng = location.getDouble("lng");

            Log.d(TAG, "Geocodificado \"" + direccion + "\" -> " + lat + ", " + lng);
            return new LatLng(lat, lng);

        } catch (Exception e) {
            Log.e(TAG, "Excepcion en geocodificacion: " + e.getMessage(), e);
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
