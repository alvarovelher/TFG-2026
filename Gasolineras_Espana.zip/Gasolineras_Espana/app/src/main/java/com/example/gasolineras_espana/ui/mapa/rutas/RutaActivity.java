package com.example.gasolineras_espana.ui.mapa.rutas;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.gasolineras_espana.BuildConfig;
import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.model.Gasolinera;
import com.example.gasolineras_espana.ui.mapa.DetalleActivity;
import com.example.gasolineras_espana.ui.mapa.MapaViewModel;
import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterItem;
import com.example.gasolineras_espana.ui.mapa.cluster.GasolineraClusterRenderer;
import com.example.gasolineras_espana.utils.FiltrosGasolineras;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.maps.android.clustering.ClusterManager;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/*
 * Activity encargada de calcular y mostrar rutas en el mapa.
 *
 * Responsabilidad:
 * Permitir al usuario indicar origen y destino, calcular la ruta con Google Routes
 * y mostrar las gasolineras cercanas a esa ruta.
 *
 * Funcionamiento:
 * - Usa el mismo MapaViewModel para reutilizar la lista de gasolineras.
 * - Permite usar "Mi ubicacion" como origen mediante FusedLocationProviderClient.
 * - Geocodifica origen y destino cuando se introducen como texto.
 * - Calcula la ruta y dibuja la polyline sobre el mapa.
 * - Filtra gasolineras cercanas a la ruta usando FiltrosGasolineras.
 * - Muestra las gasolineras filtradas mediante ClusterManager.
 */

public class RutaActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "RutaActivity";
    private static final double RADIO_KM = 5.0;     // Valor por defecto

    private GoogleMap mMap;
    private MapaViewModel viewModel;

    // Localizacion
    private FusedLocationProviderClient fusedLocationClient;

    private final ActivityResultLauncher<String> locationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted)
                    buscarYCalcular();
                else
                    Toast.makeText(this, getString(R.string.error_permiso_ubicacion), Toast.LENGTH_SHORT).show();
            });

    // ClusterManager para las gasolineras filtradas, igual que en MapaActivity
    private ClusterManager<GasolineraClusterItem> clusterManager;

    // Hilo de trabajo reutilizable: se crea una sola vez y se reutiliza en cada calculo
    private ExecutorService executor;

    // Marcadores de origen y destino (pin verde y pin rojo)
    private Marker markerOrigen;
    private Marker markerDestino;

    // Polyline de la ruta calculada, linea de "puntos"
    private Polyline polylineRuta;

    // Vistas del panel
    private AutoCompleteTextView etOrigen;
    private AutoCompleteTextView etDestino;
    private AutoCompleteTextView etFiltroCompania;
    private TextInputEditText etFiltroRadio;
    private TextInputEditText etFiltroAutonomia;
    private SwitchCompat switchFiltro24h;
    private TextView txtEstado;
    private Button btnCalcular;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruta);

        // Inicializamos el executor una sola vez para reutilizarlo en cada calculo de ruta
        executor = Executors.newSingleThreadExecutor();

        etOrigen = findViewById(R.id.etOrigen);
        etDestino = findViewById(R.id.etDestino);
        etFiltroCompania = findViewById(R.id.etFiltroCompania);
        etFiltroRadio = findViewById(R.id.etFiltroRadio);
        etFiltroAutonomia = findViewById(R.id.etFiltroAutonomia);
        switchFiltro24h   = findViewById(R.id.switchFiltro24h);
        txtEstado = findViewById(R.id.txtRutaEstado);
        btnCalcular = findViewById(R.id.btnCalcularRuta);
        progress = findViewById(R.id.progressRuta);

        // Lógica de Acordeon (Desplegables visuales)
        View btnToggleRuta = findViewById(R.id.btnToggleRuta);
        View btnToggleFiltros = findViewById(R.id.btnToggleFiltros);
        View layoutOrigenDestino = findViewById(R.id.layoutContenedorOrigenDestino);
        View layoutFiltros = findViewById(R.id.layoutContenedorFiltros);
        ImageView ivToggleRuta = findViewById(R.id.ivToggleRuta);
        ImageView ivToggleFiltros = findViewById(R.id.ivToggleFiltros);

        if (btnToggleRuta != null) {
            btnToggleRuta.setOnClickListener(v -> {
                if (layoutOrigenDestino.getVisibility() == View.VISIBLE) {
                    layoutOrigenDestino.setVisibility(View.GONE);
                    ivToggleRuta.setImageResource(android.R.drawable.arrow_down_float);
                } else {
                    layoutOrigenDestino.setVisibility(View.VISIBLE);
                    ivToggleRuta.setImageResource(android.R.drawable.arrow_up_float);
                }
            });
        }
        if (btnToggleFiltros != null) {
            btnToggleFiltros.setOnClickListener(v -> {
                if (layoutFiltros.getVisibility() == View.VISIBLE) {
                    layoutFiltros.setVisibility(View.GONE);
                    ivToggleFiltros.setImageResource(android.R.drawable.arrow_down_float);
                } else {
                    layoutFiltros.setVisibility(View.VISIBLE);
                    ivToggleFiltros.setImageResource(android.R.drawable.arrow_up_float);
                }
            });
        }

        // Tooltips informativos (Popup con Cerrar)
        TextInputLayout tilCompania = findViewById(R.id.tilFiltroCompania);
        if (tilCompania != null) {
            tilCompania.setEndIconOnClickListener(v -> mostrarInfoTooltip(getString(R.string.title_filtro_marca), getString(R.string.info_filtro_compania)));
        }
        TextInputLayout tilRadio = findViewById(R.id.tilFiltroRadio);
        if (tilRadio != null) {
            tilRadio.setEndIconOnClickListener(v -> mostrarInfoTooltip(getString(R.string.title_filtro_radio), getString(R.string.info_ruta_radio)));
        }
        TextInputLayout tilAutonomia = findViewById(R.id.tilFiltroAutonomia);
        if (tilAutonomia != null) {
            tilAutonomia.setEndIconOnClickListener(v -> mostrarInfoTooltip(getString(R.string.title_filtro_autonomia), getString(R.string.info_ruta_autonomia)));
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        TextInputLayout tilOrigen = findViewById(R.id.tilOrigen);
        if (tilOrigen != null) {
            tilOrigen.setEndIconOnClickListener(v -> etOrigen.setText(getString(R.string.mi_ubicacion)));
        }

        // Mismo ViewModel que el de la clase MapaActivity: evita recargar las gasolineras
        viewModel = new ViewModelProvider(this).get(MapaViewModel.class);
        viewModel.cargarGasolineras();

        // Cuando las gasolineras esten listas, construimos la lista de municipios para el autocompletado
        viewModel.getGasolineras().observe(this, gasolineras -> {
            if (gasolineras != null && !gasolineras.isEmpty()) {
                configurarAutocompletado(gasolineras);
            }
        });

        btnCalcular.setOnClickListener(v -> buscarYCalcular());
        findViewById(R.id.btnLimpiarRuta).setOnClickListener(v -> limpiarTodo());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapRuta);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    // Extrae los municipios unicos de las gasolineras y los mete en el adapter de autocompletado
    private void configurarAutocompletado(List<Gasolinera> gasolineras) {
        // TreeSet para obtener los nombres ordenados y sin duplicados automaticamente
        TreeSet<String> municipiosSet = new TreeSet<>();
        TreeSet<String> companiasSet = new TreeSet<>();
        for (Gasolinera g : gasolineras) {
            if (g.getMunicipio() != null && !g.getMunicipio().trim().isEmpty()) {
                municipiosSet.add(g.getMunicipio().trim());
            }
            if (g.getRotulo() != null && !g.getRotulo().trim().isEmpty()) {
                companiasSet.add(g.getRotulo().trim().toUpperCase());
            }
        }

        List<String> municipios = new ArrayList<>(municipiosSet);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, municipios);

        // El mismo adapter sirve para los dos campos
        etOrigen.setAdapter(adapter);
        etDestino.setAdapter(adapter);

        List<String> companias = new ArrayList<>(companiasSet);
        ArrayAdapter<String> adapterCompanias = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, companias);
        etFiltroCompania.setAdapter(adapterCompanias);

        Log.d(TAG, "Autocompletado listo con " + municipios.size() + " municipios");
    }

    // Configura el mapa y el cluster de gasolineras de la ruta.
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        // Vista inicial: España completa
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(40.4168, -3.7038), 5.5f));

        // Inicializamos el cluster manager con el mismo renderer personalizado que
        // MapaActivity
        clusterManager = new ClusterManager<>(this, mMap);
        GasolineraClusterRenderer renderer = new GasolineraClusterRenderer(this, mMap, clusterManager);
        clusterManager.setRenderer(renderer);
        mMap.setOnCameraIdleListener(clusterManager);
        mMap.setOnMarkerClickListener(clusterManager);

        // Click en una gasolinera: abrir pantalla de detalle
        clusterManager.setOnClusterItemClickListener(new ClusterManager.OnClusterItemClickListener<GasolineraClusterItem>() {
            @Override
            public boolean onClusterItemClick(GasolineraClusterItem item) {
                Gasolinera g = item.getGasolinera();
                if (g == null) return false;

                Intent intent = new Intent(RutaActivity.this, DetalleActivity.class);
                intent.putExtra(DetalleActivity.EXTRA_ROTULO, g.getRotulo());
                intent.putExtra(DetalleActivity.EXTRA_DIRECCION, g.getDireccion());
                intent.putExtra(DetalleActivity.EXTRA_MUNICIPIO, g.getMunicipio());
                intent.putExtra(DetalleActivity.EXTRA_HORARIO, g.getHorario());
                intent.putExtra(DetalleActivity.EXTRA_LAT, g.getLat());
                intent.putExtra(DetalleActivity.EXTRA_LON, g.getLon());

                // Bloque de precios con iconos por tipo de combustible (colores estándar UE)
                StringBuilder precios = new StringBuilder();
                if (g.getP95() > 0)           precios.append(getString(R.string.precio_p95,           String.valueOf(g.getP95()))).append("\n");
                if (g.getP98() > 0)           precios.append(getString(R.string.precio_p98,           String.valueOf(g.getP98()))).append("\n");
                if (g.getDiesel() > 0)        precios.append(getString(R.string.precio_diesel,        String.valueOf(g.getDiesel()))).append("\n");
                if (g.getDieselPremium() > 0) precios.append(getString(R.string.precio_diesel_premium, String.valueOf(g.getDieselPremium()))).append("\n");
                if (g.getGlp() > 0)           precios.append(getString(R.string.precio_glp,           String.valueOf(g.getGlp()))).append("\n");
                if (g.getGnc() > 0)           precios.append(getString(R.string.precio_gnc,           String.valueOf(g.getGnc()))).append("\n");

                String misPrecios = precios.toString().trim();
                if (misPrecios.isEmpty()) misPrecios = getString(R.string.text_precios_no_disponibles);

                intent.putExtra(DetalleActivity.EXTRA_PRECIOS, misPrecios);
                startActivity(intent);
                return true;
            }
        });
    }

    // Lee los campos de las vistas, extrae coordenadas si usamos lat/lon brutos o
    // recurre a la API de Geocoding para resolver direcciones, y delega en el hilo la peticion HTTP.
    @SuppressLint("MissingPermission")
    private void buscarYCalcular() {
        String textoOrigen = etOrigen.getText() != null ? etOrigen.getText().toString().trim() : "";
        String textoDestino = etDestino.getText() != null ? etDestino.getText().toString().trim() : "";

        // Validamos que origen y destino tengan contenido
        if (textoOrigen.isEmpty() || textoDestino.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_origen_destino), Toast.LENGTH_SHORT).show();
            return;
        }

        cerrarTeclado();

        if (textoOrigen.equalsIgnoreCase(getString(R.string.mi_ubicacion))) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
                return;
            }

            setUiCargando(true, getString(R.string.estado_obteniendo_ubicacion));
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng miPosicion = new LatLng(location.getLatitude(), location.getLongitude());
                    realizarCalculoRuta(miPosicion, textoOrigen, textoDestino);
                } else {
                    setUiCargando(false, null);
                    Toast.makeText(this, getString(R.string.error_ubicacion_no_obtenida), Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                setUiCargando(false, null);
                Toast.makeText(this, getString(R.string.error_ubicacion_fallo), Toast.LENGTH_SHORT).show();
            });
        } else {
            setUiCargando(true, getString(R.string.estado_buscando_direcciones));
            realizarCalculoRuta(null, textoOrigen, textoDestino);
        }
    }

    // Metodo asincrono: se tira contra los endpoint de Google,
    // decodifica la ruta y filtra gasolineras completamente en el hilo de fondo.
    // Solo sube al hilo principal lo estrictamente visual.
    private void realizarCalculoRuta(LatLng origenGPS, String textoOrigen, String textoDestino) {

        // Leemos los campos de la UI aqui, en el hilo principal, antes de entrar al executor.
        // Las Views no son thread-safe y no pueden tocarse desde otro hilo.
        String companiaFiltro = etFiltroCompania.getText() != null
                ? etFiltroCompania.getText().toString().trim() : null;

        double radioFiltro = RADIO_KM;
        try {
            String radioStr = etFiltroRadio.getText() != null
                    ? etFiltroRadio.getText().toString().trim() : "";
            if (!radioStr.isEmpty())
                radioFiltro = Double.parseDouble(radioStr.replace(",", "."));
        } catch (Exception ignored) { }
        if (radioFiltro < 0.5) radioFiltro = 0.5;

        double autonomiaFiltro = 0.0;
        try {
            String autoStr = etFiltroAutonomia.getText() != null
                    ? etFiltroAutonomia.getText().toString().trim() : "";
            if (!autoStr.isEmpty())
                autonomiaFiltro = Double.parseDouble(autoStr.replace(",", "."));
        } catch (Exception ignored) { }

        // Capturamos los valores finales en variables efectivamente finales para la lambda
        final double radioFinal = radioFiltro;
        final double autonomiaFinal = autonomiaFiltro;
        final String companiaFinal = companiaFiltro;
        final boolean soloAbierto24hFinal = switchFiltro24h != null && switchFiltro24h.isChecked();

        executor.execute(() -> {
            // --- TODO EN OTRO HILO ---

            // 1. Geocodificacion (peticiones HTTP)
            LatLng origen = origenGPS != null ? origenGPS
                    : GeocodingApi.geocodificar(textoOrigen, BuildConfig.ROUTES_API_KEY);
            LatLng destino = GeocodingApi.geocodificar(textoDestino, BuildConfig.ROUTES_API_KEY);

            if (origen == null || destino == null) {
                final String fallido = origen == null ? textoOrigen : textoDestino;
                runOnUiThread(() -> {
                    setUiCargando(false, null);
                    mostrarEstado(getString(R.string.estado_error_no_encontrado, fallido));
                    Toast.makeText(this, getString(R.string.error_direccion_no_localizada), Toast.LENGTH_LONG).show();
                });
                return;
            }

            runOnUiThread(() -> mostrarEstado(getString(R.string.estado_calculando_ruta)));

            // 2. Peticion HTTP a Routes API
            String encodedPolyline = RoutesApi.computeRoute(
                    origen.latitude, origen.longitude,
                    destino.latitude, destino.longitude,
                    BuildConfig.ROUTES_API_KEY);

            if (encodedPolyline == null) {
                runOnUiThread(() -> {
                    setUiCargando(false, null);
                    mostrarEstado(getString(R.string.estado_error_ruta));
                    Toast.makeText(this, getString(R.string.error_ruta_fallo), Toast.LENGTH_SHORT).show();
                });
                return;
            }

            // 3. Decodificacion de la polyline (CPU)
            List<LatLng> puntosRuta = PolylineUtils.decode(encodedPolyline);

            // 4. Filtrado de gasolineras (CPU intensivo: bounding box + Haversine)
            List<Gasolinera> todas = viewModel.getGasolineras().getValue();
            List<Gasolinera> cercanas = null;
            if (todas != null && !todas.isEmpty()) {
                cercanas = FiltrosGasolineras.aplicarFiltros(
                        todas, companiaFinal, origen, autonomiaFinal, puntosRuta, radioFinal, soloAbierto24hFinal);
            }

            // 5. Solo subimos al hilo principal lo visual: markers, polyline, cluster, estado
            final List<Gasolinera> cercanasFinal = cercanas;
            final LatLng origenFinal = origen;
            final LatLng destinoFinal = destino;
            runOnUiThread(() -> {
                setUiCargando(false, null);
                colocarMarkerOrigen(origenFinal, textoOrigen);
                colocarMarkerDestino(destinoFinal, textoDestino);
                dibujarPolyline(puntosRuta);

                if (cercanasFinal != null) {
                    cargarEnCluster(cercanasFinal);
                    mostrarEstado(getString(R.string.estado_ruta_ok, cercanasFinal.size()));
                } else {
                    mostrarEstado(getString(R.string.estado_ruta_ok_cargando));
                }
            });
        });
    }

    // Carga las gasolineras filtradas en el cluster con los markers personalizados
    private void cargarEnCluster(List<Gasolinera> gasolineras) {
        if (clusterManager == null)
            return;

        clusterManager.clearItems();
        for (Gasolinera g : gasolineras) {
            if (g.getLat() != 0.0 && g.getLon() != 0.0) {
                clusterManager.addItem(new GasolineraClusterItem(g));
            }
        }
        clusterManager.cluster();
        Log.d(TAG, "Gasolineras en ruta cargadas en cluster: " + gasolineras.size());
    }

    private void colocarMarkerOrigen(LatLng punto, String etiqueta) {
        if (markerOrigen != null)
            markerOrigen.remove();
        markerOrigen = mMap.addMarker(new MarkerOptions()
                .position(punto)
                .title(getString(R.string.marker_origen, etiqueta))
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
    }

    private void colocarMarkerDestino(LatLng punto, String etiqueta) {
        if (markerDestino != null)
            markerDestino.remove();
        markerDestino = mMap.addMarker(new MarkerOptions()
                .position(punto)
                .title(getString(R.string.marker_destino, etiqueta))
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
    }

    // Dibuja la polyline azul y ajusta la camara para ver la ruta completa
    private void dibujarPolyline(List<LatLng> puntos) {
        if (polylineRuta != null)
            polylineRuta.remove();

        polylineRuta = mMap.addPolyline(new PolylineOptions()
                .addAll(puntos)
                .color(ContextCompat.getColor(this, R.color.color_polyline_ruta))
                .width(10f)
                .geodesic(true));

        if (!puntos.isEmpty()) {
            LatLngBounds.Builder bounds = new LatLngBounds.Builder();
            for (LatLng p : puntos)
                bounds.include(p);
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 80));
        }
    }

    // Limpia el mapa y resetea los campos
    private void limpiarTodo() {
        if (markerOrigen != null) {
            markerOrigen.remove();
            markerOrigen = null;
        }
        if (markerDestino != null) {
            markerDestino.remove();
            markerDestino = null;
        }
        if (polylineRuta != null) {
            polylineRuta.remove();
            polylineRuta = null;
        }
        if (clusterManager != null)
            clusterManager.clearItems();

        etOrigen.setText("");
        etDestino.setText("");
        etFiltroCompania.setText("");
        etFiltroRadio.setText("");
        etFiltroAutonomia.setText("");
        if (switchFiltro24h != null) switchFiltro24h.setChecked(false);
        txtEstado.setVisibility(View.GONE);

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(40.4168, -3.7038), 5.5f));
    }

    private void setUiCargando(boolean cargando, String mensajeCarga) {
        progress.setVisibility(cargando ? View.VISIBLE : View.GONE);
        btnCalcular.setEnabled(!cargando);
        if (cargando && mensajeCarga != null)
            mostrarEstado(mensajeCarga);
    }

    private void mostrarEstado(String texto) {
        txtEstado.setText(texto);
        txtEstado.setVisibility(View.VISIBLE);
    }

    private void mostrarInfoTooltip(String titulo, String mensaje) {
        new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensaje)
                .setPositiveButton(getString(R.string.btn_cerrar), null)
                .show();
    }

    private void cerrarTeclado() {
        View foco = getCurrentFocus();
        if (foco != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(foco.getWindowToken(), 0);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Apagamos el executor limpiamente al destruir la Activity para liberar el hilo
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
