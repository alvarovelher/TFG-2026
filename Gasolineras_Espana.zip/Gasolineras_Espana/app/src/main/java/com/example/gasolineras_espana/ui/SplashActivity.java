package com.example.gasolineras_espana.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gasolineras_espana.R;
import com.example.gasolineras_espana.data.GasolinerasRepository;
import com.example.gasolineras_espana.ui.mapa.MapaActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        com.airbnb.lottie.LottieAnimationView lottieSplash = findViewById(R.id.lottieSplash);
        
        // El JSON de Lottie pide la fuente "Lato", pero como no la tenemos en assets,
        // le decimos que use la fuente por defecto del sistema para que no crashee.
        lottieSplash.setFontAssetDelegate(new com.airbnb.lottie.FontAssetDelegate() {
            @Override
            public android.graphics.Typeface fetchFont(String fontFamily) {
                return android.graphics.Typeface.DEFAULT_BOLD;
            }
        });

        // Habilitamos "Merge Paths" que pide el log para que se vea mejor
        lottieSplash.enableMergePathsForKitKatAndAbove(true);

        // Forzamos la descarga/carga en el repositorio
        // Esto comprobará si el archivo local existe y si es de hoy. Si no lo es, lo baja.
        GasolinerasRepository.getInstance().cargarDesdeLocalOInternet(this);

        // Transición a MainActivity (Login) después de 5 segundos
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 5000);
    }
}
